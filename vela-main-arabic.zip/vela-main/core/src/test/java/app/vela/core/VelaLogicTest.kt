package app.vela.core

import app.vela.core.data.google.PolylineCodec
import app.vela.core.data.google.parse.DirectionsParser
import app.vela.core.data.google.parse.PhotosParser
import app.vela.core.data.google.parse.SearchParser
import app.vela.core.data.google.parse.TransitParser
import app.vela.core.model.Photo
import app.vela.core.model.TransitMode
import app.vela.core.model.LatLng
import app.vela.core.model.distanceTo
import app.vela.core.model.Maneuver
import app.vela.core.model.ManeuverType
import app.vela.core.model.Route
import app.vela.core.model.RouteLeg
import app.vela.core.model.TravelMode
import app.vela.core.nav.NavEngine
import app.vela.core.nav.NavEvent
import app.vela.core.nav.NavReplay
import app.vela.core.nav.NavState
import app.vela.core.replay.TripLog
import app.vela.core.nav.ShieldType
import app.vela.core.nav.parseRouteRef
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlinx.serialization.json.Json

class PolylineCodecTest {

    /** Reference vector straight from Google's encoded-polyline documentation. */
    @Test
    fun decodesGoogleReferenceVector() {
        val pts = PolylineCodec.decode("_p~iF~ps|U_ulLnnqC_mqNvxq`@")
        assertEquals(3, pts.size)
        assertEquals(38.5, pts[0].lat, 1e-5)
        assertEquals(-120.2, pts[0].lng, 1e-5)
        assertEquals(40.7, pts[1].lat, 1e-5)
        assertEquals(-120.95, pts[1].lng, 1e-5)
        assertEquals(43.252, pts[2].lat, 1e-5)
        assertEquals(-126.453, pts[2].lng, 1e-5)
    }

    @Test
    fun roundTrips() {
        val path = listOf(
            LatLng(37.7749, -122.4194),
            LatLng(37.7849, -122.4094),
            LatLng(37.7949, -122.3994),
        )
        val again = PolylineCodec.decode(PolylineCodec.encode(path))
        assertEquals(path.size, again.size)
        for (i in path.indices) {
            assertEquals(path[i].lat, again[i].lat, 1e-5)
            assertEquals(path[i].lng, again[i].lng, 1e-5)
        }
    }
}

class NavEngineTest {

    private fun straightRoute(): Route {
        val a = LatLng(37.0000, -122.0000)
        val mid = LatLng(37.0050, -122.0000)
        val b = LatLng(37.0100, -122.0000)
        return Route(
            polyline = listOf(a, mid, b),
            legs = listOf(
                RouteLeg(
                    distanceMeters = 1100.0,
                    durationSeconds = 80.0,
                    durationInTrafficSeconds = null,
                    maneuvers = listOf(
                        Maneuver(ManeuverType.DEPART, "Head north", a, 1100.0, 80.0),
                        Maneuver(ManeuverType.ARRIVE, "Arrive", b, 0.0, 0.0),
                    ),
                ),
            ),
            distanceMeters = 1100.0,
            durationSeconds = 80.0,
            durationInTrafficSeconds = null,
        )
    }

    @Test
    fun advancesPastDepartThenArrives() {
        val route = straightRoute()
        val start = route.polyline.first()
        val (afterStart, _) = NavEngine.update(route, NavState(), start)
        assertTrue("should advance off the DEPART step", afterStart.stepIndex >= 1)

        val (arrived, events) = NavEngine.update(route, afterStart, route.polyline.last())
        assertTrue("should mark arrived at destination", arrived.arrived)
        assertTrue("should emit an Arrived event", events.any { it is NavEvent.Arrived })
    }

    /** "Take exit 186" speaks as "take the 186 exit" - the espeak G2P mangles the bare
     *  take-exit adjacency ("tacake", user ear-report 2026-07-16); "take the" is the onset it
     *  reliably gets right. Display text is untouched (this is the speech expansion). */
    @Test
    fun takeExitSpeaksWithTheArticle() {
        val en = app.vela.core.i18n.EnNavStrings
        assertTrue(en.expandForSpeech("Take exit 186, toward somewhere").startsWith("take the 186 exit"))
        assertTrue(en.expandForSpeech("Take exit 72B").startsWith("take the 72B exit"))
        assertEquals("Turn right onto Main Street", en.expandForSpeech("Turn right onto Main Street"))
    }

    /** Sub-mile spoken distances phrase as quarter-mile fractions, never "zero point five miles". */
    @Test
    fun spokenMilesUseFractionsBelowAMile() {
        val en = app.vela.core.i18n.EnNavStrings
        assertEquals("a quarter mile", en.spokenDistance(400.0, imperial = true))
        assertEquals("half a mile", en.spokenDistance(805.0, imperial = true))
        assertEquals("three quarters of a mile", en.spokenDistance(1207.0, imperial = true))
        assertEquals("1 mile", en.spokenDistance(1609.0, imperial = true))
        assertEquals("1.2 miles", en.spokenDistance(1931.0, imperial = true))
        assertEquals("500 meters", en.spokenDistance(500.0, imperial = false)) // metric untouched
    }

    /** The SPOKEN sign drops secondary destinations after the colon; plain instructions and
     *  colons outside a sign ("Opens at 9:00") are untouched. */
    @Test
    fun spokenSignDropsSecondarySignDestinations() {
        val en = app.vela.core.i18n.EnNavStrings
        assertEquals(
            "Take the ramp on the left toward I 5 North",
            en.spokenSign("Take the ramp on the left toward I 5 North: Vancouver British Columbia"),
        )
        assertEquals("Turn right onto Main Street", en.spokenSign("Turn right onto Main Street"))
        assertEquals("Arrive: 9:00 PM", en.spokenSign("Arrive: 9:00 PM")) // no " toward " -> untouched
    }

    /** A MERGE announces at most twice (near band + turn-now): a long on-ramp used to narrate
     *  the same road three times in declining counts (real-drive report 2026-07-17). */
    @Test
    fun mergeGetsOneApproachPrompt() {
        val a = LatLng(37.0000, -122.0000)
        val m = LatLng(37.0200, -122.0000)
        val b = LatLng(37.0400, -122.0000)
        val route = Route(
            polyline = listOf(a, m, b),
            legs = listOf(
                RouteLeg(
                    distanceMeters = 4400.0, durationSeconds = 200.0, durationInTrafficSeconds = null,
                    maneuvers = listOf(
                        Maneuver(ManeuverType.DEPART, "Head north", a, 2200.0, 100.0),
                        Maneuver(ManeuverType.MERGE, "Merge onto I-80 East", m, 2200.0, 100.0),
                        Maneuver(ManeuverType.ARRIVE, "Arrive", b, 0.0, 0.0),
                    ),
                ),
            ),
            distanceMeters = 4400.0, durationSeconds = 200.0, durationInTrafficSeconds = null,
        )
        var state = NavEngine.update(route, NavState(), a).first
        val speaks = ArrayList<String>()
        var lat = 37.0000
        while (lat < 37.0210 && state.stepIndex < 2) {
            lat += 0.0004 // ~45 m steps
            val (n, ev) = NavEngine.update(route, state, LatLng(lat, -122.0))
            state = n
            ev.filterIsInstance<NavEvent.Speak>().forEach { speaks += it.text }
        }
        val merges = speaks.filter { it.contains("Merge onto") }
        assertTrue("merge should be announced, got: $speaks", merges.isNotEmpty())
        assertTrue("merge spoken at most twice (near + turn-now), got: $merges", merges.size <= 2)
    }

    /** A step's second and third prompts drop the sign-destination tail: the far band names the
     *  destination once, the repeats say just the action ("Take the ramp on the right"). */
    @Test
    fun repeatedRampPromptsDropTheDestinationTail() {
        val a = LatLng(37.0000, -122.0000)
        val r = LatLng(37.0200, -122.0000)
        val b = LatLng(37.0400, -122.0000)
        val full = "Take the ramp on the right toward CA-99 North"
        val route = Route(
            polyline = listOf(a, r, b),
            legs = listOf(
                RouteLeg(
                    distanceMeters = 4400.0, durationSeconds = 200.0, durationInTrafficSeconds = null,
                    maneuvers = listOf(
                        Maneuver(ManeuverType.DEPART, "Head north", a, 2200.0, 100.0),
                        Maneuver(ManeuverType.RAMP_RIGHT, full, r, 2200.0, 100.0),
                        Maneuver(ManeuverType.ARRIVE, "Arrive", b, 0.0, 0.0),
                    ),
                ),
            ),
            distanceMeters = 4400.0, durationSeconds = 200.0, durationInTrafficSeconds = null,
        )
        var state = NavEngine.update(route, NavState(), a).first
        val speaks = ArrayList<String>()
        var lat = 37.0000
        while (lat < 37.0210 && state.stepIndex < 2) {
            lat += 0.0004
            val (n, ev) = NavEngine.update(route, state, LatLng(lat, -122.0))
            state = n
            ev.filterIsInstance<NavEvent.Speak>().forEach { speaks += it.text }
        }
        val ramps = speaks.filter { it.contains("Take the ramp") }
        assertTrue("expected multiple ramp prompts, got: $speaks", ramps.size >= 2)
        assertTrue("the FIRST prompt carries the sign destination: ${ramps.first()}", ramps.first().contains("toward CA-99 North"))
        ramps.drop(1).forEach {
            assertTrue("repeats drop the destination tail: $it", !it.contains("toward"))
        }
    }

    @Test
    fun detectsOffRoute() {
        val route = straightRoute()
        // ~400m east of the north-south line → well past the off-route threshold.
        val offPoint = LatLng(37.0050, -121.9955)
        var state = NavState()
        var sawReroute = false
        repeat(6) {
            val (next, events) = NavEngine.update(route, state, offPoint)
            state = next
            if (events.any { it is NavEvent.RerouteNeeded }) sawReroute = true
        }
        assertTrue("repeated off-route fixes should request a reroute", sawReroute)
    }

    @Test
    fun rerouteRequestedOnceNotEveryFix() {
        val route = straightRoute()
        val offPoint = LatLng(37.0050, -121.9955)
        var state = NavState()
        var reroutes = 0
        repeat(8) {
            val (next, events) = NavEngine.update(route, state, offPoint)
            state = next
            reroutes += events.count { it is NavEvent.RerouteNeeded }
        }
        // Edge-triggered: one request on the off-route transition, not one per fix.
        assertEquals(1, reroutes)
    }

    /** Walking/biking get a tighter off-route corridor than driving (NavSession passes it): a
     *  pedestrian is on a known path a few meters wide, so a wrong turn should be caught long before
     *  the 40 m a car needs for lane offset + shallow-angle lag. Same ~30 m deviation: inside the
     *  driving corridor (no reroute), outside the walking one (reroutes). */
    @Test
    fun tighterCorridorReroutesWhereWideDoesNot() {
        val route = straightRoute()
        // ~30 m east of the north-south line: within driving's 40 m, beyond walking's 22 m.
        val offPoint = LatLng(37.0050, -121.99966)
        val speed = 1.4 // walking pace; floor pinned to 0.6 so this counts as moving in both runs

        var driveReroutes = 0
        run {
            var state = NavState()
            repeat(6) {
                val (n, ev) = NavEngine.update(route, state, offPoint, speedMps = speed, movingFloorMps = 0.6)
                state = n
                driveReroutes += ev.count { it is NavEvent.RerouteNeeded }
            }
        }
        assertEquals("30 m is inside the 40 m driving corridor - no reroute", 0, driveReroutes)

        var sawWalkReroute = false
        run {
            var state = NavState()
            repeat(6) {
                val (n, ev) = NavEngine.update(
                    route, state, offPoint,
                    speedMps = speed, movingFloorMps = 0.6, offRouteM = 22.0, farOffM = 45.0,
                )
                state = n
                if (ev.any { it is NavEvent.RerouteNeeded }) sawWalkReroute = true
            }
        }
        assertTrue("30 m exceeds the 22 m walking corridor - should reroute", sawWalkReroute)
    }

    /** Heading term: a wrong turn onto a road that stays INSIDE the distance corridor never used
     *  to latch off-route - the engine kept guiding on the old route with no reroute and no
     *  redrawn line. Moving against the route's direction now counts as off-route hits. */
    @Test
    fun wrongWayInsideCorridorStillReroutes() {
        val route = straightRoute() // due north
        var state = NavState()
        var sawReroute = false
        repeat(6) { i ->
            // Fixes ON the line (offDist ~0) but coursing EAST, perpendicular to the route.
            val pt = LatLng(37.0010 + i * 0.0001, -122.0000)
            val (next, events) = NavEngine.update(route, state, pt, speedMps = 10.0, bearingDeg = 90.0)
            state = next
            if (events.any { it is NavEvent.RerouteNeeded }) sawReroute = true
        }
        assertTrue("driving 90 deg against the route must reroute even inside the corridor", sawReroute)
    }

    @Test
    fun alignedCourseInsideCorridorDoesNotLatch() {
        val route = straightRoute() // due north
        var state = NavState()
        repeat(6) { i ->
            val pt = LatLng(37.0010 + i * 0.0001, -122.0000)
            val (next, events) = NavEngine.update(route, state, pt, speedMps = 10.0, bearingDeg = 2.0)
            state = next
            assertTrue("aligned course on the line must not reroute", events.none { it is NavEvent.RerouteNeeded })
        }
        assertTrue(!state.offRoute)
    }

    /** The off-route corridor scales with GPS accuracy (OsmAnd-style) and stays mode-relative:
     *  tighter on a clean fix, wider on a noisy one, foot < bike < drive, clamped both ends. */
    @Test
    fun offRouteCorridorScalesWithAccuracyAndMode() {
        // Widens as the fix degrades.
        assertTrue(
            "a noisy fix must widen the corridor",
            NavEngine.offRouteCorridor(TravelMode.DRIVE, 5.0) < NavEngine.offRouteCorridor(TravelMode.DRIVE, 30.0),
        )
        // Foot tighter than bike tighter than drive at the same accuracy.
        val acc = 12.0
        assertTrue(
            "foot < bike < drive at equal accuracy",
            NavEngine.offRouteCorridor(TravelMode.WALK, acc) < NavEngine.offRouteCorridor(TravelMode.BICYCLE, acc) &&
                NavEngine.offRouteCorridor(TravelMode.BICYCLE, acc) < NavEngine.offRouteCorridor(TravelMode.DRIVE, acc),
        )
        // Driving self-tightens below the old flat 40 m when GPS is clean ("40 is too high").
        assertTrue(
            "a clean fix drives tighter than the old 40 m",
            NavEngine.offRouteCorridor(TravelMode.DRIVE, 5.0) < 40.0,
        )
        // Clamps: a wildly coarse fix caps out; a null fix uses the typical-GPS default (not the floor).
        assertEquals(70.0, NavEngine.offRouteCorridor(TravelMode.DRIVE, 500.0), 1e-9)
        assertEquals(42.0, NavEngine.offRouteCorridor(TravelMode.DRIVE, null), 1e-9)
        // Far distance is always beyond the corridor and capped per mode.
        assertTrue(NavEngine.farOffDistance(TravelMode.DRIVE, 40.0) > 40.0)
        assertEquals(60.0, NavEngine.farOffDistance(TravelMode.WALK, 40.0), 1e-9) // 2×40 capped to 60
    }

    /** Off-route mutes turn guidance: while a reroute is pending the progress snap still maps the
     *  driver onto the OLD route, and the engine used to announce that route's maneuvers as the
     *  phantom snap drifted past them ("turn right onto X" spoken on a street it doesn't exist
     *  on). Muted while the latch is up; guidance resumes the moment the driver is back on line. */
    @Test
    fun offRouteMutesOldRouteTurnPrompts() {
        val a = LatLng(37.0000, -122.0000)
        val mid = LatLng(37.0050, -122.0000)
        val b = LatLng(37.0100, -122.0000)
        val route = Route(
            polyline = listOf(a, mid, b),
            legs = listOf(
                RouteLeg(
                    distanceMeters = 1100.0, durationSeconds = 80.0, durationInTrafficSeconds = null,
                    maneuvers = listOf(
                        Maneuver(ManeuverType.DEPART, "Head north", a, 550.0, 40.0),
                        Maneuver(ManeuverType.TURN_RIGHT, "Turn right onto Oak", mid, 550.0, 40.0),
                        Maneuver(ManeuverType.ARRIVE, "Arrive", b, 0.0, 0.0),
                    ),
                ),
            ),
            distanceMeters = 1100.0, durationSeconds = 80.0, durationInTrafficSeconds = null,
        )
        // Drive OFF the line (~400 m east) until the off-route latch is up.
        var state = NavState()
        repeat(6) { state = NavEngine.update(route, state, LatLng(37.0020, -121.9955)).first }
        assertTrue("latched off-route", state.offRoute)
        // Still off-route, the phantom snap drifts into the turn's approach band: stay silent.
        val (next, muted) = NavEngine.update(route, state, LatLng(37.0037, -121.9955))
        assertTrue("no old-route turn prompts while off-route", muted.none { it is NavEvent.Speak })
        // Back ON the line short of the turn: the latch clears and guidance resumes.
        val (_, resumed) = NavEngine.update(route, next, LatLng(37.0040, -122.0000))
        assertTrue("guidance resumes once back on the route", resumed.any { it is NavEvent.Speak })
    }

    @Test
    fun offRouteClearsWhenBackOnPath() {
        val route = straightRoute()
        val offPoint = LatLng(37.0050, -121.9955)
        var state = NavState()
        repeat(6) { state = NavEngine.update(route, state, offPoint).first }
        assertTrue("should be off-route after repeated off fixes", state.offRoute)

        val (back, _) = NavEngine.update(route, state, LatLng(37.0050, -122.0000)) // on the line
        assertTrue("off-route should clear once back on the path", !back.offRoute)
        assertEquals(0, back.offRouteHits)
    }

    /** The back-on-course discriminator for the reroute-abandon: offRoute clears on a SINGLE grazing
     *  fix, which is too weak to abandon an in-flight reroute on (a spurious graze on a parallel leg would
     *  kill a real missed-turn reroute). onRouteStreak requires a SUSTAINED rejoin. */
    @Test
    fun onRouteStreakNeedsSustainedRejoinNotOneGraze() {
        val route = straightRoute()
        val offPoint = LatLng(37.0050, -121.9955)
        val onLine = LatLng(37.0050, -122.0000)
        var state = NavState()
        repeat(6) { state = NavEngine.update(route, state, offPoint).first }
        assertTrue("off-route after repeated off fixes", state.offRoute)
        assertEquals("off the line → streak is 0", 0, state.onRouteStreak)

        // ONE fix back on the line clears the offRoute latch, but it's a single graze — streak = 1, below
        // the back-on-course threshold (2), so NavSession must NOT abandon a reroute on it yet.
        state = NavEngine.update(route, state, onLine).first
        assertTrue("one on-line fix clears the latch", !state.offRoute)
        assertEquals("but one fix is not a sustained rejoin", 1, state.onRouteStreak)

        // A second consecutive on-line fix → solidly back on course (streak reaches the threshold).
        state = NavEngine.update(route, state, onLine).first
        assertEquals(2, state.onRouteStreak)

        // A single off fix immediately resets the streak — a graze can never accumulate to the threshold.
        state = NavEngine.update(route, state, offPoint).first
        assertEquals(0, state.onRouteStreak)
    }

    /** Reaching a non-final maneuver advances the step but must NOT mark arrival —
     *  only the final ARRIVE maneuver does. */
    @Test
    fun arrivalRequiresTheFinalManeuver() {
        val a = LatLng(37.0000, -122.0000)
        val mid = LatLng(37.0050, -122.0000)
        val b = LatLng(37.0100, -122.0000)
        val route = Route(
            polyline = listOf(a, mid, b),
            legs = listOf(
                RouteLeg(
                    distanceMeters = 1100.0,
                    durationSeconds = 80.0,
                    durationInTrafficSeconds = null,
                    maneuvers = listOf(
                        Maneuver(ManeuverType.DEPART, "Head north", a, 550.0, 40.0),
                        Maneuver(ManeuverType.TURN_RIGHT, "Turn right", mid, 550.0, 40.0),
                        Maneuver(ManeuverType.ARRIVE, "Arrive", b, 0.0, 0.0),
                    ),
                ),
            ),
            distanceMeters = 1100.0,
            durationSeconds = 80.0,
            durationInTrafficSeconds = null,
        )
        val (s1, _) = NavEngine.update(route, NavState(), a) // off DEPART
        assertTrue(s1.stepIndex >= 1)
        val (s2, e2) = NavEngine.update(route, s1, mid) // at the middle turn
        assertTrue("a non-final maneuver must not arrive", !s2.arrived)
        assertTrue("no Arrived event mid-route", e2.none { it is NavEvent.Arrived })
        val (s3, e3) = NavEngine.update(route, s2, b) // the final point
        assertTrue("the final maneuver arrives", s3.arrived)
        assertTrue(e3.any { it is NavEvent.Arrived })
    }

    /** A route that passes near itself: up the west line, a tiny hop east, back down a
     *  parallel east line ~5 m away (an out-and-back / switchback). A naïve global-nearest
     *  "remaining" matches the return leg and collapses to almost-arrived while you're still
     *  on the way out. Forward progress must keep it honest. Regression for the test-drive's
     *  "51 mi to turn · 0.3 mi remaining". */
    private fun hairpinRoute(): Route {
        val a = LatLng(37.0000, -122.00000)
        val t = LatLng(37.0100, -122.00000)   // top of the outbound (west) leg
        val t2 = LatLng(37.0100, -121.99994)  // hop ~5 m east
        val m2 = LatLng(37.0050, -121.99994)  // mid inbound (east) leg — ~5 m from the outbound midpoint
        val b = LatLng(37.0000, -121.99994)   // end, beside the start
        return Route(
            polyline = listOf(a, t, t2, m2, b),
            legs = listOf(
                RouteLeg(
                    distanceMeters = 2232.0,
                    durationSeconds = 200.0,
                    durationInTrafficSeconds = null,
                    maneuvers = listOf(
                        Maneuver(ManeuverType.DEPART, "Head north", a, 0.0, 0.0),
                        Maneuver(ManeuverType.UTURN, "Make a U-turn", t, 1113.0, 100.0),
                        Maneuver(ManeuverType.ARRIVE, "Arrive", b, 1119.0, 100.0),
                    ),
                ),
            ),
            distanceMeters = 2232.0,
            durationSeconds = 200.0,
            durationInTrafficSeconds = null,
        )
    }

    @Test
    fun remainingStaysHonestWhenRoutePassesNearItself() {
        val route = hairpinRoute()
        // Drive up the outbound (west) leg: start, ~quarter, ~halfway.
        var state = NavEngine.update(route, NavState(), LatLng(37.0000, -122.0000)).first
        state = NavEngine.update(route, state, LatLng(37.0030, -122.0000)).first
        val remAtQuarter = state.remainingDistance
        state = NavEngine.update(route, state, LatLng(37.0050, -122.0000)).first // ~5 m from the inbound leg

        // Global-nearest would snap onto the return leg here and report ~560 m (almost
        // arrived). Forward progress keeps it honest: ~556 m covered of ~2232 m → ~1675 left.
        assertTrue(
            "remaining must not collapse onto the nearby return leg (was ${state.remainingDistance})",
            state.remainingDistance > 1400.0,
        )
        // The contradiction the user saw — next turn farther than the whole trip — must not happen.
        assertTrue(
            "next-turn (${state.distanceToNextManeuver}) can't exceed remaining (${state.remainingDistance})",
            state.distanceToNextManeuver <= state.remainingDistance + 1.0,
        )
        // Progress is monotonic and advancing.
        assertTrue("remaining should shrink as we drive", state.remainingDistance < remAtQuarter)
        assertTrue("traveled progress should advance", state.traveledM in 450.0..700.0)
    }

    // --- regression tests for the 2026-06-27 highway-drive bugs (turns 6 mi out of sync) ----

    /** A turn must sit at the START of its step, not the end. The off-by-one (adding the step
     *  length BEFORE placing) put every turn a whole step too far — a 9 km highway step landed
     *  the exit 9 km past where it actually is. */
    @Test
    fun maneuverSitsAtStartOfItsStepNotEnd() {
        val a = LatLng(37.0000, -122.0000)
        val b = LatLng(37.0900, -122.0000) // ~10 km straight north
        val maneuvers = listOf(
            Maneuver(ManeuverType.DEPART, "Head north", LatLng(0.0, 0.0), 1000.0, 0.0),
            Maneuver(ManeuverType.RAMP_RIGHT, "Take the exit", LatLng(0.0, 0.0), 9000.0, 0.0),
            Maneuver(ManeuverType.ARRIVE, "Arrive", LatLng(0.0, 0.0), 0.0, 0.0),
        )
        val exit = DirectionsParser.placeManeuvers(maneuvers, listOf(a, b))[1].location
        // The exit opens its 9 km step → ~1 km from the start, NOT ~10 km (parked at the end).
        assertTrue("exit must be ~1 km from start, was ${exit.distanceTo(a)} m", exit.distanceTo(a) < 2000.0)
        assertTrue("exit must NOT be parked at the route end", exit.distanceTo(b) > 5000.0)
    }

    /** A maneuver that's geographically NEAR an early point but FAR along the route (a highway
     *  curving back near an exit) must not be announced/advanced early — prompts + advancement
     *  measure ALONG the route, not crow-flies. */
    @Test
    fun doesNotSkipAManeuverNearByCrowFliesButFarAlongTheRoute() {
        val a = LatLng(37.0000, -122.0000)
        val far = LatLng(37.0500, -122.0000)   // ~5.5 km north
        val back = LatLng(37.0000, -122.0001)  // ~9 m WEST of A, but ~11 km along the route
        val end = LatLng(37.0000, -122.0050)
        val route = Route(
            polyline = listOf(a, far, back, end),
            legs = listOf(
                RouteLeg(
                    distanceMeters = 11000.0, durationSeconds = 600.0, durationInTrafficSeconds = null,
                    maneuvers = listOf(
                        Maneuver(ManeuverType.DEPART, "Head north", a, 11000.0, 600.0),
                        Maneuver(ManeuverType.TURN_RIGHT, "Turn right", back, 400.0, 30.0),
                        Maneuver(ManeuverType.ARRIVE, "Arrive", end, 0.0, 0.0),
                    ),
                ),
            ),
            distanceMeters = 11000.0, durationSeconds = 600.0, durationInTrafficSeconds = null,
        )
        val (s1, _) = NavEngine.update(route, NavState(), a)  // consume DEPART
        assertEquals("should be targeting the turn", 1, s1.stepIndex)
        val (s2, _) = NavEngine.update(route, s1, a)          // still at the start
        assertEquals("must NOT skip the loop-back turn that's only ~9 m away crow-flies", 1, s2.stepIndex)
    }

    // Units are checked on a real turn's approach prompt — the DEPART maneuver is spoken by
    // NavSession.start and skipped by the engine (advance past it first).
    private fun turnRoute(): Route {
        val a = LatLng(37.0000, -122.0000)
        val turn = LatLng(37.0030, -122.0000) // ~334 m north — inside the 400 m prompt
        val end = LatLng(37.0030, -121.9960)
        return Route(
            polyline = listOf(a, turn, end),
            legs = listOf(
                RouteLeg(
                    distanceMeters = 700.0, durationSeconds = 60.0, durationInTrafficSeconds = null,
                    maneuvers = listOf(
                        Maneuver(ManeuverType.DEPART, "Head north", a, 334.0, 30.0),
                        Maneuver(ManeuverType.TURN_RIGHT, "Turn right onto Larch Way", turn, 366.0, 30.0),
                        Maneuver(ManeuverType.ARRIVE, "Arrive", end, 0.0, 0.0),
                    ),
                ),
            ),
            distanceMeters = 700.0, durationSeconds = 60.0, durationInTrafficSeconds = null,
        )
    }

    /** Spoken prompt distances follow the Imperial setting (TTS used to always say meters). */
    @Test
    fun spokenPromptsUseImperialWhenImperial() {
        val r = turnRoute()
        val (s1, _) = NavEngine.update(r, NavState(), r.polyline.first(), imperial = true) // consume DEPART
        val (_, events) = NavEngine.update(r, s1, r.polyline.first(), imperial = true)     // ~334 m out → prompt turn
        val spoken = events.filterIsInstance<NavEvent.Speak>().map { it.text }
        assertTrue("a prompt should use feet/miles, got $spoken", spoken.any { it.contains("feet") || it.contains("mile") })
        assertTrue("must not say meters in imperial mode, got $spoken", spoken.none { it.contains("meter") })
    }

    @Test
    fun spokenPromptsUseMetersWhenMetric() {
        val r = turnRoute()
        val (s1, _) = NavEngine.update(r, NavState(), r.polyline.first(), imperial = false) // consume DEPART
        val (_, events) = NavEngine.update(r, s1, r.polyline.first(), imperial = false)      // ~334 m out → prompt turn
        val spoken = events.filterIsInstance<NavEvent.Speak>().map { it.text }
        assertTrue("a prompt should use meters, got $spoken", spoken.any { it.contains("meter") })
    }

    /** Vela SPEAKS the road name — "turn right onto Larch Way" — not the bare "turn right" modern
     *  Google Maps shortened its voice cue to. We reuse the written instruction (which keeps the
     *  name) for TTS, so the name must survive into the spoken event. */
    @Test
    fun spokenPromptNamesTheRoad() {
        val a = LatLng(37.0000, -122.0000)
        val turn = LatLng(37.0030, -122.0000)   // ~334 m north — inside the 400 m prompt, outside 150 m
        val end = LatLng(37.0030, -121.9960)
        val route = Route(
            polyline = listOf(a, turn, end),
            legs = listOf(
                RouteLeg(
                    distanceMeters = 700.0, durationSeconds = 60.0, durationInTrafficSeconds = null,
                    maneuvers = listOf(
                        Maneuver(ManeuverType.DEPART, "Head north", a, 334.0, 30.0),
                        Maneuver(ManeuverType.TURN_RIGHT, "Turn right onto Larch Way", turn, 366.0, 30.0),
                        Maneuver(ManeuverType.ARRIVE, "Arrive", end, 0.0, 0.0),
                    ),
                ),
            ),
            distanceMeters = 700.0, durationSeconds = 60.0, durationInTrafficSeconds = null,
        )
        val (s1, _) = NavEngine.update(route, NavState(), a, imperial = true) // consume DEPART
        val (_, events) = NavEngine.update(route, s1, a, imperial = true)     // ~334 m out → prompt the turn
        val spoken = events.filterIsInstance<NavEvent.Speak>().map { it.text }
        assertTrue("the spoken prompt must name the road, got $spoken", spoken.any { it.contains("Larch Way") })
    }
}

/** The offline nav auditor ([NavReplay]) — replays a GPS track through the real engine and diffs
 *  the cards/voice against the plotted route's actual maneuver positions. These are the automation
 *  that lets a saved trip be checked without remembering where it went wrong. */
class NavReplayTest {

    /** Walk [poly] into evenly-spaced fixes (~[stepM] apart) that follow it exactly — a clean drive. */
    private fun densify(poly: List<LatLng>, stepM: Double = 15.0): List<LatLng> {
        val out = ArrayList<LatLng>()
        for (i in 0 until poly.size - 1) {
            val a = poly[i]; val b = poly[i + 1]
            val steps = maxOf(1, (a.distanceTo(b) / stepM).toInt())
            for (s in 0 until steps) {
                val t = s.toDouble() / steps
                out += LatLng(a.lat + (b.lat - a.lat) * t, a.lng + (b.lng - a.lng) * t)
            }
        }
        out += poly.last()
        return out
    }

    /** North, then east, then north again — two real turns plus depart/arrive. */
    private fun lRoute(): Route {
        val a = LatLng(37.0000, -122.0000)
        val c1 = LatLng(37.0100, -122.0000)  // ~1.11 km north — turn right
        val c2 = LatLng(37.0100, -121.9900)  // ~0.89 km east — turn left
        val end = LatLng(37.0200, -121.9900) // ~1.11 km north — arrive
        return Route(
            polyline = listOf(a, c1, c2, end),
            legs = listOf(
                RouteLeg(
                    distanceMeters = 3100.0, durationSeconds = 240.0, durationInTrafficSeconds = null,
                    maneuvers = listOf(
                        Maneuver(ManeuverType.DEPART, "Head north", a, 1113.0, 86.0),
                        Maneuver(ManeuverType.TURN_RIGHT, "Turn right onto B Street", c1, 888.0, 70.0),
                        Maneuver(ManeuverType.TURN_LEFT, "Turn left onto C Avenue", c2, 1113.0, 84.0),
                        Maneuver(ManeuverType.ARRIVE, "Arrive at destination", end, 0.0, 0.0),
                    ),
                ),
            ),
            distanceMeters = 3100.0, durationSeconds = 240.0, durationInTrafficSeconds = null,
        )
    }

    @Test
    fun auditsACleanDriveWithNoSuspects() {
        val route = lRoute()
        val report = NavReplay.analyze(route, densify(route.polyline), imperial = true)

        assertTrue("should produce per-fix cards", report.cards.isNotEmpty())
        // Every real turn (not the DEPART — NavSession.start speaks that — nor the arrival) gets a
        // spoken pre-turn prompt and a turn-now cue. The engine advances past the DEPART silently.
        val realTurns = report.maneuvers.filter { it.type != ManeuverType.ARRIVE && it.type != ManeuverType.DEPART }
        assertTrue("every turn announced: ${report.summary()}", realTurns.all { it.announced })
        assertTrue("every turn got a turn-now cue", realTurns.all { it.turnNowFired })
        assertTrue("arrival should fire", report.maneuvers.last().turnNowFired)
        // The DEPART is intentionally silent in the engine (spoken once by NavSession.start instead).
        val depart = report.maneuvers.first { it.type == ManeuverType.DEPART }
        assertTrue("DEPART must not be re-announced by the engine", !depart.announced)
        // The card distance tracks reality closely on a clean drive, and nothing is flagged.
        assertTrue("card error should stay small, was ${report.worstCardErrorM}", report.worstCardErrorM < 150.0)
        assertTrue("a clean drive must flag nothing:\n${report.summary()}", report.suspects.isEmpty())
        // The analyzer's MEASUREMENTS must be right — that's what makes it trustworthy on real
        // logs: turns announced ~400 m out (the prompt distance), and the track passing through
        // each turn (nearest ≈ 0). These are the numbers I'll read off a shipped travel log.
        realTurns.filter { it.type != ManeuverType.DEPART }.forEach {
            val ahead = it.firstAnnounceAheadM ?: -1.0
            assertTrue("turn ${it.index} announced $ahead out — expected ~400 m lead", ahead in 250.0..450.0)
            assertTrue("track should pass through turn ${it.index} (nearest ${it.nearestApproachM})", it.nearestApproachM < 20.0)
        }
    }

    /** The diff/flagging logic itself — the heuristics that turn raw measurements into "this turn's
     *  guidance disagreed with the blue line". Tested directly (the robust engine won't emit these
     *  on a synthetic clean route, but a real Google-data glitch can). */
    @Test
    fun flagsTheGuidanceBugsButNotACleanTurn() {
        fun diff(
            type: ManeuverType, announced: Boolean, turnNow: Boolean,
            firstAhead: Double?, cardErr: Double, nearest: Double,
        ) = NavReplay.ManeuverDiff(1, type, "x", 1000.0, announced, turnNow, firstAhead, cardErr, nearest)

        // A normal turn: announced ~400 m out, turn-now fired, card accurate, drove through it.
        val clean = diff(ManeuverType.TURN_RIGHT, announced = true, turnNow = true, firstAhead = 390.0, cardErr = 30.0, nearest = 4.0)
        assertTrue("a clean turn must not be flagged", !clean.suspect)
        assertTrue(clean.flags.isEmpty())

        // Silent exit: drove right past a turn that was never announced (the field "went quiet" bug).
        val silent = diff(ManeuverType.RAMP_RIGHT, announced = false, turnNow = false, firstAhead = null, cardErr = 20.0, nearest = 25.0)
        assertTrue("a silent missed turn must be flagged", silent.suspect)
        assertTrue("…and labeled silent: ${silent.flags}", silent.flags.any { it.contains("SILENT") })

        // Announced miles too early (the "exit in 6 miles that didn't exist yet" bug).
        val early = diff(ManeuverType.RAMP_RIGHT, announced = true, turnNow = true, firstAhead = 9000.0, cardErr = 50.0, nearest = 5.0)
        assertTrue("a too-early announcement must be flagged", early.suspect)
        assertTrue("…and labeled early: ${early.flags}", early.flags.any { it.contains("early") })

        // Card lying about the distance to the next turn.
        val liar = diff(ManeuverType.CONTINUE, announced = true, turnNow = true, firstAhead = 300.0, cardErr = 5000.0, nearest = 5.0)
        assertTrue("a wildly wrong card distance must be flagged", liar.suspect)
        assertTrue("…and labeled as a card error: ${liar.flags}", liar.flags.any { it.contains("card off") })

        // A genuinely missing arrival/depart shouldn't trip the turn-only heuristics.
        val arrive = diff(ManeuverType.ARRIVE, announced = false, turnNow = false, firstAhead = null, cardErr = 40.0, nearest = 10.0)
        assertTrue("ARRIVE/DEPART are exempt from the silent-turn rule", !arrive.suspect)
    }

    /** The whole shipped-log pipeline: encode a route + fixes in the exact on-device CSV format,
     *  parse it back, and audit it — so a real travel log can be dropped in and analyzed in one
     *  call. Guards the TripStore ↔ TripLog format contract too. */
    @Test
    fun roundTripsAndAuditsASavedTripCsv() {
        val route = lRoute()
        val fixes = densify(route.polyline)
        val csv = buildString {
            val dst = route.polyline.last()
            append("META,Test Drive,1700000000000,${dst.lat},${dst.lng}\n")
            append(TripLog.encodeRoute(route)) // the same block TripStore.saveRoute writes
            for (f in fixes) append("${f.lat},${f.lng},0,0.0,12.0\n")
        }

        val parsed = TripLog.parse(csv)
        assertEquals("label round-trips", "Test Drive", parsed.label)
        assertEquals("polyline round-trips", route.polyline.size, parsed.route?.polyline?.size)
        assertEquals("maneuvers round-trip", route.maneuvers.size, parsed.route?.maneuvers?.size)
        assertEquals("every GPS fix parsed (route lines skipped)", fixes.size, parsed.points.size)

        val report = TripLog.audit(csv)
            ?: throw AssertionError("audit returned null — the saved route didn't parse")
        assertTrue("end-to-end audit of a clean saved trip flags nothing:\n${report.summary()}", report.suspects.isEmpty())
    }

    /**
     * On-demand harness for a REAL shared travel log. Point it at a trip CSV exported from the
     * phone and it prints the per-maneuver audit plus the spoken-line timeline (where along the
     * route each voice cue fired) — the concrete "how the cards/voice differ from the blue line".
     *
     *   ./gradlew :core:testDebugUnitTest --tests '*auditSharedTripLog' -DvelaTrip=/abs/path/trip.csv --info
     *
     * Skipped (not failed) when `-DvelaTrip` is unset, so normal/CI runs ignore it.
     */
    /**
     * ON-DEMAND ROUTER PROBE for a shared trip's segment (2026-09-13, built for the faster-route
     * swap that collapsed a 17.9 km route into one maneuver at the start): re-runs the open
     * router from the segment's recorded start through vias sampled off its recorded polyline,
     * exactly as the traffic snap does, and prints every maneuver with its type, text, distance
     * and where it resolved. Compare with the trip's own M lines to see whether the routing or
     * the engine mangled it.
     *
     *   ./gradlew :core:testDebugUnitTest --tests '*probeTripSegmentRoute' -DvelaTrip=/abs/trip.csv -DvelaSeg=1 --rerun-tasks
     */
    @Test
    fun probeTripSegmentRoute() {
        val path = System.getProperty("velaTrip")
        org.junit.Assume.assumeTrue("set -DvelaTrip=<csv> and -DvelaSeg=<n>", !path.isNullOrBlank())
        val seg = (System.getProperty("velaSeg") ?: "0").toInt()
        val parsed = TripLog.parse(java.io.File(path!!).readText())
        val route = parsed.segments.getOrNull(seg)?.route ?: run { println("[probe] no segment $seg"); return }
        val poly = route.polyline
        val http = okhttp3.OkHttpClient()
        fun dump(tag: String, r: Route?) {
            if (r == null) { println("[probe] $tag: null"); return }
            println("[probe] $tag: ${r.distanceMeters.toInt()} m, ${r.maneuvers.size} maneuvers, abbreviated=${r.abbreviatedSteps}")
            r.maneuvers.forEachIndexed { i, m ->
                val d = m.location.distanceTo(poly.first()).toInt()
                println("   [$i] ${m.type} \"${m.instruction}\" road=${m.road} ref=${m.ref} dist=${m.distanceMeters.toInt()} atStart=${d}m")
            }
        }
        println("[probe] segment $seg: recorded ${route.distanceMeters.toInt()} m, ${route.maneuvers.size} maneuvers; start=${poly.first()} end=${poly.last()}")
        route.maneuvers.forEachIndexed { i, m -> println("   rec[$i] ${m.type} \"${m.instruction}\" dist=${m.distanceMeters.toInt()} atStart=${m.location.distanceTo(poly.first()).toInt()}m") }
        val p0 = poly.first(); val p1 = poly[minOf(3, poly.lastIndex)]
        val b = (Math.toDegrees(Math.atan2(
            Math.sin(Math.toRadians(p1.lng - p0.lng)) * Math.cos(Math.toRadians(p1.lat)),
            Math.cos(Math.toRadians(p0.lat)) * Math.sin(Math.toRadians(p1.lat)) - Math.sin(Math.toRadians(p0.lat)) * Math.cos(Math.toRadians(p1.lat)) * Math.cos(Math.toRadians(p1.lng - p0.lng)),
        )) + 360.0) % 360.0
        dump("plain OSRM", app.vela.core.data.RouteGeometry.route(http, poly.first(), poly.last(), app.vela.core.model.TravelMode.DRIVE).firstOrNull())
        dump("plain OSRM with depart bearing $b", app.vela.core.data.RouteGeometry.route(http, poly.first(), poly.last(), app.vela.core.model.TravelMode.DRIVE, departBearingDeg = b).firstOrNull())
        val vias = app.vela.core.data.RouteGeometry.sampleVias(poly)
        dump("via snap (${vias.size} vias, strict)", app.vela.core.data.RouteGeometry.routeVia(http, listOf(poly.first()) + vias + poly.last(), app.vela.core.model.TravelMode.DRIVE, strictVias = true).firstOrNull())
        dump("via snap with depart bearing", app.vela.core.data.RouteGeometry.routeVia(http, listOf(poly.first()) + vias + poly.last(), app.vela.core.model.TravelMode.DRIVE, departBearingDeg = b, strictVias = true).firstOrNull())
    }

    @Test
    fun `a folded rename is kept on the leg and roadAt follows it`() {
        val turn = Maneuver(ManeuverType.TURN_RIGHT, "Turn right onto Oak Street", LatLng(38.5, -121.7), 400.0, 30.0, road = "Oak Street")
        val rename = Maneuver(ManeuverType.CONTINUE, "Continue onto Elm Street", LatLng(38.51, -121.7), 600.0, 40.0, road = "Elm Street")
        val next = Maneuver(ManeuverType.TURN_LEFT, "Turn left onto Pine Street", LatLng(38.52, -121.7), 100.0, 10.0, road = "Pine Street")
        val folded = app.vela.core.data.RouteGeometry.foldRenames(listOf(turn, rename, next))
        assertEquals(2, folded.size)
        val leg = folded[0]
        assertEquals(1000.0, leg.distanceMeters, 0.001)
        assertEquals(listOf(app.vela.core.model.RoadRename(400.0, "Elm Street", null)), leg.renames)
        assertEquals("Oak Street", leg.roadAt(0.0).first)
        assertEquals("Oak Street", leg.roadAt(399.0).first)
        assertEquals("Elm Street", leg.roadAt(400.0).first)
        assertEquals("Elm Street", leg.roadAt(950.0).first)
        // A leg with no rename answers its own road at any distance.
        assertEquals("Pine Street", folded[1].roadAt(50.0).first)
    }

    /** On-demand: route A to B on the open router and print every maneuver's road / ref / text.
     *  `-DvelaProbe=lat,lng;lat,lng` (forwarded like velaTrip). */
    @Test
    fun probeRouteFields() {
        val spec = System.getProperty("velaProbe")
        org.junit.Assume.assumeTrue("set -DvelaProbe=lat,lng;lat,lng", !spec.isNullOrBlank())
        val (a, b) = spec!!.split(";").map { it.split(",").map(String::toDouble) }.map { LatLng(it[0], it[1]) }
        val r = app.vela.core.data.RouteGeometry.route(okhttp3.OkHttpClient(), a, b, app.vela.core.model.TravelMode.DRIVE).firstOrNull()
        println("[probe] ${r?.maneuvers?.size} maneuvers")
        r?.maneuvers?.forEachIndexed { i, m -> println("   [$i] ${m.type} road=${m.road?.let { "\"$it\"" }} ref=${m.ref?.let { "\"$it\"" }} text=\"${m.instruction}\"") }
    }

    @Test
    fun `provider, off-route hits and K lines ride the trip and survive the scrub`() {
        val csv = "META,x,0,,,3217\n" +
            "38.5,-121.7,1000,10,5,0,4.0,gps,0\n" +
            "K,1500,recheck: kept current route (candidate saves 12 s)\n" +
            "38.51,-121.71,2000,10,5,1,25.0,network,2\n"
        val parsed = TripLog.parse(csv)
        assertEquals("gps", parsed.points[0].provider)
        assertEquals(0, parsed.points[0].offRouteHits)
        assertEquals("network", parsed.points[1].provider)
        assertEquals(2, parsed.points[1].offRouteHits)
        assertEquals(listOf("K"), parsed.events.map { it.tag })
        // Older recordings without the columns still parse.
        assertEquals(null, TripLog.parse("META,x,0,,,3217\n38.5,-121.7,1000,10,5\n").points[0].provider)
    }

    @Test
    fun `route provenance flags ride the RD line and parse back`() {
        val route = Route(
            listOf(LatLng(38.5, -121.7), LatLng(38.51, -121.71)),
            listOf(app.vela.core.model.RouteLeg(1500.0, 120.0, null, listOf(
                Maneuver(ManeuverType.DEPART, "Head out", LatLng(38.5, -121.7), 1500.0, 120.0),
            ))),
            1500.0, 120.0, null, provisional = true, abbreviatedSteps = true,
        )
        val block = TripLog.encodeRoute(route, "faster")
        val rd = block.lines().first { it.startsWith("RD,") }
        assertTrue(rd, rd.endsWith(",faster,provisional;abbreviated;steps=1"))
        val parsed = TripLog.parse("META,x,0,,,3217\n" + block + "38.5,-121.7,0,0,0\n")
        assertEquals("faster", parsed.segments.single().reason)
        assertEquals("provisional;abbreviated;steps=1", parsed.segments.single().flags)
    }

    @Test
    fun auditSharedTripLog() {
        val path = System.getProperty("velaTrip")
        org.junit.Assume.assumeTrue("set -DvelaTrip=<csv> to audit a real travel log", !path.isNullOrBlank())
        val csv = java.io.File(path!!).readText()
        val report = TripLog.audit(csv)
        if (report == null) {
            println("[NavReplay] $path has no saved route — replay re-routes; nothing to diff against")
            return
        }
        val ver = TripLog.parse(csv).versionCode
        println("[NavReplay] auditing $path (recorded by build ${ver ?: "pre-2026-07-16, unknown"})\n${report.summary()}")
        val parsed2 = TripLog.parse(csv)
        val pts = parsed2.points
        val offFixes = pts.count { it.offRoute }
        if (offFixes > 0) {
            var spans = 0; var prev = false
            pts.forEach { if (it.offRoute && !prev) spans++; prev = it.offRoute }
            println("[NavReplay] recorded off-route flag: $offFixes fixes in $spans span(s)")
        }
        if (parsed2.segments.size > 1) {
            println("[NavReplay] route swaps:")
            parsed2.segments.drop(1).forEach { seg ->
                println("  @fix ${seg.fromPoint}: ${seg.reason ?: "(unrecorded reason)"}${seg.flags?.let { " [$it]" } ?: ""}")
            }
        }
        // What the road pill shows partway along each step of each recorded route.
        parsed2.segments.forEachIndexed { si, seg ->
            val mans = seg.route?.maneuvers ?: return@forEachIndexed
            println("[NavReplay] road label by step, route $si:")
            mans.forEachIndexed { i, m ->
                println("  [$i] ${m.instruction} -> ${app.vela.core.nav.roadLabelAt(mans, i + 1, m.distanceMeters / 2, orNext = true) ?: "(none)"}")
            }
        }
        val byProvider = pts.groupingBy { it.provider ?: "(unrecorded)" }.eachCount()
        println("[NavReplay] fixes by provider: " + byProvider.entries.joinToString { "${it.key}=${it.value}" })
        val decisions = parsed2.events.filter { it.tag == "K" }
        if (decisions.isNotEmpty()) {
            println("[NavReplay] nav decisions (${decisions.size}):")
            decisions.forEach { println("  @${it.t / 1000}s: ${it.text}") }
        }
        val spoken = parsed2.events.filter { it.tag == "S" }
        if (spoken.isNotEmpty()) {
            println("[NavReplay] recorded speech (${spoken.size} lines):")
            spoken.forEach { e -> println("  @${(e.t - parsed2.startedAt) / 1000}s: ${e.text}") }
        }
        val jank = parsed2.events.filter { it.tag == "J" }
        if (jank.isNotEmpty()) {
            var fr = 0L; var ja = 0L; var worst = 0
            jank.forEach { e ->
                val p = e.text.split(',')
                fr += p.getOrNull(0)?.toLongOrNull() ?: 0
                ja += p.getOrNull(1)?.toLongOrNull() ?: 0
                worst = maxOf(worst, p.getOrNull(2)?.toIntOrNull() ?: 0)
            }
            val pct = if (fr > 0) "%.1f".format(100.0 * ja / fr) else "?"
            println("[NavReplay] recorded frame pacing: $fr frames, $ja janky ($pct%), worst ${worst}ms")
        }
        val batt = parsed2.events.filter { it.tag == "B" }.mapNotNull { it.text.toIntOrNull() }
        if (batt.size >= 2) println("[NavReplay] battery over the drive: ${batt.first()}% -> ${batt.last()}%")
        println("[NavReplay] spoken-line timeline (fix @ meters-along-route):")
        report.cards.filter { it.spoke.isNotEmpty() }.forEach { c ->
            println("  @${c.fixIndex} (${c.alongM.toInt()} m): ${c.spoke.joinToString(" | ")}")
        }
    }
}

/** Maneuver parsing pinned to the REAL keyless step markup (captured live from
 *  www.google.com/maps/preview/directions): a generic `maneuver='TURN'` token with the direction
 *  in a child `<turn side= type=>`. The old mapType only knew `TURN_LEFT`-style tokens, so every
 *  plain turn/ramp fell through to UNKNOWN — generic arrow + wrong haptic. */
class DirectionsManeuverTest {

    @Test
    fun mapsRealKeylessTurnTokensAndKeepsRoadName() {
        val left = DirectionsParser.parseStep(
            "<step maneuver='TURN' meters='420'>Turn <turn side='LEFT'>left</turn> onto " +
                "<roadlist><road lang='en'>Covell Blvd</road></roadlist></step>",
        )
        assertEquals("a plain TURN must resolve its side, not fall to UNKNOWN", ManeuverType.TURN_LEFT, left.type)
        assertEquals("Turn left onto Covell Blvd", left.instruction)

        val ramp = DirectionsParser.parseStep(
            "<step maneuver='ON_RAMP' meters='2246'>Slight <turn side='RIGHT' type='SLIGHT'>right</turn> " +
                "onto the ramp to <signlist><sign lang='en'>Sacramento</sign></signlist></step>",
        )
        assertEquals(ManeuverType.RAMP_RIGHT, ramp.type)
        assertTrue("ramp instruction kept", ramp.instruction.contains("ramp to Sacramento"))

        val roundabout = DirectionsParser.parseStep(
            "<step maneuver='ROUNDABOUT_ENTER_AND_EXIT' meters='4557'>At the traffic circle, take the " +
                "<exit number='SECOND'>2nd</exit> exit</step>",
        )
        assertEquals(ManeuverType.ROUNDABOUT, roundabout.type)
        assertEquals("At the traffic circle, take the 2nd exit", roundabout.instruction)

        // sharp + slight variants resolve too
        assertEquals(
            ManeuverType.SLIGHT_RIGHT,
            DirectionsParser.parseStep("<step maneuver='TURN' meters='5'>Slight <turn side='RIGHT' type='SLIGHT'>right</turn></step>").type,
        )
        assertEquals(
            ManeuverType.TURN_RIGHT,
            DirectionsParser.parseStep("<step maneuver='TURN' meters='5'>Turn <turn side='RIGHT'>right</turn></step>").type,
        )
    }
}

class PhotosParserTest {

    /** The hspqX response is the chunked batchexecute envelope: `)]}'`, a length
     *  line, then the `["wrb.fr","hspqX",<payload-json-string>,…]` row. Photos live
     *  at payload[0][i][6][0]; the FIFE size suffix is normalized. */
    @Test
    fun extractsUserPhotosAndDropsStreetView() {
        // Real anonymous responses interleave Street View thumbnails (no Google
        // login) at the same [6][0] leaf — those must be filtered out, or they
        // render as non-loading placeholders.
        val payload = """[[["pid1",10,12,null,null,null,["https://lh3.googleusercontent.com/abc=w2117-h1000-k-no","",[4608,2176]]],""" +
            """["sv",0,1,null,null,null,["https://streetviewpixels-pa.googleapis.com/v1/thumbnail?panoid=xyz"]],""" +
            """["pid2",10,12,null,null,null,["https://lh3.googleusercontent.com/def=w1776-h1000-k-no"]]],1]"""
        val escaped = payload.replace("\\", "\\\\").replace("\"", "\\\"")
        val body = ")]}'\n\n321\n[[\"wrb.fr\",\"hspqX\",\"$escaped\",null,null,null,\"generic\"],[\"di\",45]]\n"
        val photos = PhotosParser.parse(body)
        assertEquals(2, photos.size) // the Street View entry is dropped
        assertEquals("https://lh3.googleusercontent.com/abc=w1024-h768", photos[0].url)
        assertEquals("https://lh3.googleusercontent.com/def=w1024-h768", photos[1].url)
        assertTrue(photos.none { it.url.contains("streetviewpixels") })
        assertEquals(null, photos[0].postedText) // no [21][6][8] in this payload
    }

    /** Posted date from `entry[21][6][8]` = `[year, month, day, hour]` → "May 2026". */
    @Test
    fun readsPostedDate() {
        val entry = (0..21).joinToString(",", "[", "]") { i ->
            when (i) {
                0 -> "\"pid\""
                6 -> "[\"https://lh3.googleusercontent.com/xyz=w800-h600-k-no\"]"
                21 -> "[null,null,null,null,null,null,[null,null,null,null,null,null,null,null,[2026,5,25,14]]]"
                else -> "null"
            }
        }
        val payload = "[[$entry],1]"
        val escaped = payload.replace("\\", "\\\\").replace("\"", "\\\"")
        val body = ")]}'\n\n9\n[[\"wrb.fr\",\"hspqX\",\"$escaped\",null,null,null,\"generic\"]]\n"
        val photos = PhotosParser.parse(body)
        assertEquals(1, photos.size)
        assertEquals("May 2026", photos[0].postedText)
    }

    @Test
    fun returnsEmptyOnGarbage() {
        assertEquals(emptyList<Photo>(), PhotosParser.parse(""))
        assertEquals(emptyList<Photo>(), PhotosParser.parse(")]}'\n\n5\n[[\"er\",null]]"))
    }
}

class SearchParserHoursTest {

    private fun json(s: String) = Json.parseToJsonElement(s)

    /** Day-entry shape from the live response — the `[203][0]` and `[118][0][3][0]`
     *  formats share it: day name at `[0]`, hours text at `[3][0][0]`. */
    @Test
    fun parsesWeeklyHours() {
        val days = json(
            """
            [
              ["Tuesday",2,[2026,6,16],[["6 AM–8 PM",[[6],[20]]]],0,1],
              ["Wednesday",3,[2026,6,17],[["7 AM–9 PM",[[7],[21]]]],0,1]
            ]
            """.trimIndent(),
        )
        assertEquals(
            listOf("Tuesday: 6 AM–8 PM", "Wednesday: 7 AM–9 PM"),
            SearchParser.readHours(days),
        )
    }

    @Test // real structure from a live capture: multiple ranges per day + a holiday label at day[6][1]
    fun readHoursJoinsRangesAndKeepsHolidayLabel() {
        val days = json(
            """
            [
              ["Saturday",6,[2026,7,4],[["Closed"]],1,2,["4th of July hours","4th of July",1]],
              ["Sunday",7,[2026,7,5],[["9 AM–12 PM",[[9],[12]]],["1 PM–5 PM",[[13],[17]]]],0,1]
            ]
            """.trimIndent(),
        )
        assertEquals(
            listOf("Saturday: Closed · 4th of July", "Sunday: 9 AM–12 PM, 1 PM–5 PM"),
            SearchParser.readHours(days),
        )
    }

    @Test
    fun ignoresNonHourArrays() {
        assertEquals(emptyList<String>(), SearchParser.readHours(null))
        assertEquals(emptyList<String>(), SearchParser.readHours(json("[[1,2,3],[4,5,6]]")))
    }

    /** Some places' formatted address is prefixed with the business name; the sheet already shows the
     *  name on its own line, so the parser strips a clean name prefix (only at a real word boundary). */
    @Test
    fun stripsBusinessNamePrefixFromAddress() {
        assertEquals("1451 W Covell Blvd, Davis, CA 95616",
            SearchParser.stripNamePrefix("Safeway, 1451 W Covell Blvd, Davis, CA 95616", "Safeway"))
        assertEquals("1451 W Covell Blvd",
            SearchParser.stripNamePrefix("Safeway 1451 W Covell Blvd", "Safeway"))
        // Not a prefix → untouched.
        assertEquals("100 Main St", SearchParser.stripNamePrefix("100 Main St", "Safeway"))
        // Prefix but no word boundary ("Safeway" vs "Safeways Plaza") → leave it, don't mangle.
        assertEquals("Safeways Plaza Dr", SearchParser.stripNamePrefix("Safeways Plaza Dr", "Safeway"))
        // A bare space alone is NOT a boundary — the next token must be the street NUMBER, else a
        // street merely named after the place would be beheaded ("Plaza, …" / "Access Rd, the metro").
        assertEquals(
            "Safeway Plaza, 1451 W Covell Blvd",
            SearchParser.stripNamePrefix("Safeway Plaza, 1451 W Covell Blvd", "Safeway"),
        )
        assertEquals("Boeing Access Rd, the metro", SearchParser.stripNamePrefix("Boeing Access Rd, the metro", "Boeing"))
        // Unexpected continuation (apostrophe) → leave untouched rather than half-strip.
        assertEquals("Safeway's Fuel, 123 Main St", SearchParser.stripNamePrefix("Safeway's Fuel, 123 Main St", "Safeway"))
        // Stripping would empty the line → keep original.
        assertEquals("Safeway", SearchParser.stripNamePrefix("Safeway", "Safeway"))
    }

    /** Price level derived from Google's dollar-range / symbol label (the response
     *  never ships the classic 1–4), powering the price filter. */
    @Test
    fun derivesPriceLevelFromLabel() {
        assertEquals(1, SearchParser.priceLevelOf("$1–10"))
        assertEquals(2, SearchParser.priceLevelOf("$10–20"))
        assertEquals(3, SearchParser.priceLevelOf("$20–30"))
        assertEquals(4, SearchParser.priceLevelOf("$50+"))
        assertEquals(2, SearchParser.priceLevelOf("$$"))   // symbol style
        assertEquals(4, SearchParser.priceLevelOf("$$$$"))
        assertEquals(null, SearchParser.priceLevelOf(null))
        assertEquals(null, SearchParser.priceLevelOf(""))
    }

    /** Phase-2: the parser reads every field from the *provided* path map, so a
     *  remote calibration can relocate an index without an app update. Fixture
     *  uses low indices (results at root[0]; name/coords/address shallow) — proving
     *  parse() honors the supplied paths rather than the hard-coded ones. */
    @Test
    fun readsFieldsFromProvidedPaths() {
        val root = json(
            """[ [ [ null, ["Joe's Cafe", [37.5, -122.5], "1 Main St, SF, CA 94101"] ] ] ]""",
        )
        val paths = mapOf(
            "results" to listOf(0),
            "name" to listOf(1, 0),
            "lat" to listOf(1, 1, 0),
            "lng" to listOf(1, 1, 1),
            "address" to listOf(1, 2),
        )
        val places = SearchParser.parse("q", root, null, paths).places
        assertEquals(1, places.size)
        assertEquals("Joe's Cafe", places[0].name)
        assertEquals("1 Main St, SF, CA 94101", places[0].address)
        assertEquals(37.5, places[0].location.lat, 1e-6)
        assertEquals(-122.5, places[0].location.lng, 1e-6)
    }
}

class TransitParserTest {
    private fun fixture(name: String) = javaClass.getResourceAsStream("/google_transit/$name")!!.bufferedReader().readText()

    // The same Shinjuku to Tokyo Station trips captured from the app in Japanese and in English
    // (issue #674). Everything the parser derives from numbers must agree between the two; only
    // the names differ. The page's own clock text does differ ("5:38" and "5:38 AM").
    @Test fun theSameTripParsesAlikeInJapaneseAndEnglish() {
        app.vela.core.data.ClockFormat.use24h = false
        val ja = TransitParser.parse(fixture("tokyo-ja.json"))
        val en = TransitParser.parse(fixture("tokyo-en.json"))
        assertEquals(2, ja.size); assertEquals(2, en.size)
        val j = ja[0]; val e = en[0]
        assertEquals(e.departureEpochSec, j.departureEpochSec)
        assertEquals(e.departureText, j.departureText)
        assertEquals(e.arrivalText, j.arrivalText)
        assertTrue(Regex("""\d{1,2}:\d{2} [AP]M""").matches(j.departureText!!))
        assertEquals(e.steps.size, j.steps.size)
        val jr = j.steps.first { it.line != null }; val er = e.steps.first { it.line != null }
        assertEquals("中央線", jr.line!!.name)
        assertEquals("東京行", jr.headsign)
        assertEquals("新宿駅", jr.boardStop!!.name)
        assertEquals("Shinjuku Station", er.boardStop!!.name)
        assertEquals(er.boardStop!!.timeText, jr.boardStop!!.timeText)
        assertEquals(er.alightStop!!.timeText, jr.alightStop!!.timeText)
        assertEquals(er.numStops, jr.numStops)
        assertEquals(er.line!!.colorHex, jr.line!!.colorHex)
        // The destination, not the service type that sits before it in the badge.
        assertTrue(er.headsign!!.contains("Tokyo", ignoreCase = true) || er.headsign!!.contains("Tōkyō"))
        app.vela.core.data.ClockFormat.use24h = true
        assertTrue(Regex("""\d{2}:\d{2}""").matches(TransitParser.parse(fixture("tokyo-ja.json"))[0].departureText!!))
        app.vela.core.data.ClockFormat.use24h = false
    }


    // Faithful to a live Davis→Sacramento `!3e3` capture (2026-06-18): trips at
    // root[0][1], each trip is [summary, …] so the summary is trip[0]; within the
    // summary distance [2][1], duration [3][1], depart/arrive [5][0]/[5][1] =
    // [epochSec, tz, "h:mm AM"], agency [6][4][0][0], and line nodes ["<name>", n,
    // "#fill", "#text"] interleaved with mode-icon facets in [14]. The Amtrak
    // trip's badge carries a "bus2.png"/"Bus" facet → mode BUS.
    private val itin0 = """[null,null,[null,"15.0 miles"],[null,"45 min"],null,""" +
        """[[1781788200,"America/Los_Angeles","6:10 AM"],[1781790924,"America/Los_Angeles","6:55 AM"]],""" +
        """[null,null,null,null,[["Amtrak Chartered Vehicle"]]],null,null,null,null,null,null,null,""" +
        """[[4,null,[3,"bus2.png",null,"Bus"]],[5,["Amtrak Thruway Connecting Service",1,"#cae4f1","#000000"]]]]"""
    private val itin1 = """[null,null,[null,"3.2 miles"],[null,"1 hr 8 min"],null,""" +
        """[[1781786400,"America/Los_Angeles","5:40 AM"],[1781790480,"America/Los_Angeles","6:48 AM"]],""" +
        """null,null,null,null,null,null,null,null,""" +
        """[[4,null,[3,"bus2.png",null,"Bus"]],[5,["Route 42B",1,"#0b8043","#ffffff"]]]]"""

    @Test
    fun parsesTransitItineraries() {
        // each trip wraps its summary at [0] — root[0][1] = [[summary0],[summary1]]
        val list = TransitParser.parse(Json.parseToJsonElement("[[null,[[$itin0],[$itin1]]]]"))
        assertEquals(2, list.size)
        val a = list[0]
        assertEquals("45 min", a.durationText)
        assertEquals("15.0 miles", a.distanceText)
        assertEquals("6:10 AM", a.departureText)
        assertEquals("6:55 AM", a.arrivalText)
        assertEquals(1781788200L, a.departureEpochSec)
        assertEquals(1781790924L, a.arrivalEpochSec)
        assertEquals("Amtrak Chartered Vehicle", a.agency)
        assertEquals(1, a.lines.size)
        assertEquals("Amtrak Thruway Connecting Service", a.lines[0].name)
        assertEquals("#cae4f1", a.lines[0].colorHex)
        assertEquals("#000000", a.lines[0].textColorHex)
        assertEquals(TransitMode.BUS, a.lines[0].mode)
        // second itinerary's line is read independently
        assertEquals("Route 42B", list[1].lines[0].name)
        assertEquals("#0b8043", list[1].lines[0].colorHex)
    }

    @Test
    fun transitFrequencyComesFromTripThirteen() {
        // trip[13] = [seconds, "10 min", seconds] where the service has a headway (live London,
        // New York and SF trips, 2026-09-29); absent or out of range = no frequency line.
        val withFreq = "[$itin0,null,null,null,null,null,null,null,null,null,null,null,null,[600,\"10 min\",600]]"
        val silly = "[$itin1,null,null,null,null,null,null,null,null,null,null,null,null,[5,\"5 s\",5]]"
        val list = TransitParser.parse(Json.parseToJsonElement("[[null,[$withFreq,$silly,[$itin1]]]]"))
        assertEquals("10 min", list[0].frequencyText)
        org.junit.Assert.assertNull(list[1].frequencyText)
        org.junit.Assert.assertNull(list[2].frequencyText)
    }

    @Test(expected = app.vela.core.data.CalibrationNeededException::class)
    fun throwsWhenShapeMissing() {
        TransitParser.parse(Json.parseToJsonElement("[[1,2,3]]"))
    }

    // Drill-down legs live at trip[1][0][1] in the same payload: each leg's
    // summary is leg[0] (dur [3][1], dist [2][1], mode/line badge [14]); board/
    // alight times are the first/last "h:mm AM" strings anywhere in the leg.
    private val walkLeg = """[[null,null,[null,"0.3 mi"],[null,"7 min"],null,null,null,null,null,null,null,null,null,null,""" +
        """[[4,null,[3,"walk.png",null,"Walk"]]]]]"""
    private val busLeg = """[[null,null,null,[null,"53 min"],null,null,null,null,null,null,null,null,null,null,""" +
        """[[4,null,[3,"bus2.png",null,"Bus"]],[5,["42B",1,"#008751","#ffffff"]]]],""" +
        """null,null,null,null,[["Fifth St & G St","5:48 AM"],["W. Capitol","6:41 AM"]]]"""

    @Test
    fun parsesTransitStepsFromSamePayload() {
        val legs = "[[null,[$walkLeg,$busLeg]]]" // = trip[1]; trip[1][0][1] is the leg list
        val list = TransitParser.parse(Json.parseToJsonElement("[[null,[[$itin0,$legs]]]]"))
        assertEquals(1, list.size)
        val steps = list[0].steps
        assertEquals(2, steps.size)
        // leg 0 — a walk: no line, no board/alight time, but a duration + distance
        assertEquals(TransitMode.WALK, steps[0].mode)
        assertEquals("7 min", steps[0].durationText)
        assertEquals("0.3 mi", steps[0].distanceText)
        assertEquals(null, steps[0].line)
        assertEquals(null, steps[0].departText)
        // leg 1 — the ride: line, color, board + alight times
        assertEquals(TransitMode.BUS, steps[1].mode)
        assertEquals("53 min", steps[1].durationText)
        assertEquals("42B", steps[1].line?.name)
        assertEquals("#008751", steps[1].line?.colorHex)
        assertEquals("5:48 AM", steps[1].departText)
        assertEquals("6:41 AM", steps[1].arriveText)
    }

    // Real-shaped ride leg from the Miami→Aventura `!3e3` capture (2026-07-07). The ride's stop
    // block is leg[5]: board [5][0], alight [5][1], stop count [5][2], intermediate list [5][7];
    // each stop node holds name [0], agency code [1], and time tuples (real-time [2]/[3],
    // timetable [7]/[8]). Headsign is leg[0][14][2][1][0]; agency+phone leg[0][6][4][0][0]/[4];
    // service alerts leg[0][9][k][2]. Board is 5 min late (RT 4:35 vs timetable 4:30).
    private val boardStop = """["NE 10 Av & NE 175 St","A10V1752",null,""" +
        """[1783456549,"America/New_York","4:35 PM"],null,null,null,null,""" +
        """[1783456243,"America/New_York","4:30 PM"],null,3]"""
    private val alightStop = """["Aventura Blvd & #2740 (Bank)","AVTB#276",""" +
        """[1783457640,"America/New_York","4:54 PM"],null,null,null,null,""" +
        """[1783457340,"America/New_York","4:49 PM"],null,null,3]"""
    private val intermStop = """["NE 10 Av & NE 180 Ter","A10V1801",""" +
        """[1783456644,"America/New_York","4:37 PM"],null,null,null,null,null,null,null,3]"""
    private val ride = """[$boardStop,$alightStop,17,"#5c7ca2",0,null,2,[$intermStop]]"""
    private val richBusLeg = """[[null,null,null,[null,"19 min"],null,null,""" +
        """[null,null,null,null,[["Miami-Dade Transit","id",null,null,"1 (305) 891-3131"]]],""" +
        """null,null,[[2,"Information","Route 9 / 9A - Southbound Midtown Detour"]],null,null,null,null,""" +
        """[[4,null,[3,"bus2.png",null,"Bus"]],[5,["9",1,"#5c7ca2","#ffffff"]],[7,["Aventura Mall Terminal Via M. Gardens Dr"]]]],""" +
        """null,null,null,null,$ride]"""

    @Test
    fun parsesRideStopDetail() {
        val legs = "[[null,[$richBusLeg]]]"
        val list = TransitParser.parse(Json.parseToJsonElement("[[null,[[$itin0,$legs]]]]"))
        val trip = list[0]
        val ride = trip.steps.single { it.line != null }
        assertEquals("9", ride.line?.name)
        assertEquals("Aventura Mall Terminal Via M. Gardens Dr", ride.headsign)
        assertEquals(17, ride.numStops)
        // board / alight stops with codes + real-time times
        assertEquals("NE 10 Av & NE 175 St", ride.boardStop?.name)
        assertEquals("A10V1752", ride.boardStop?.code)
        assertEquals("4:35 PM", ride.boardStop?.timeText)
        assertEquals("4:30 PM", ride.boardStop?.scheduledText) // differs → shown struck
        assertEquals("Aventura Blvd & #2740 (Bank)", ride.alightStop?.name)
        assertEquals("4:54 PM", ride.alightStop?.timeText)
        assertEquals("5 min late", ride.delayText)
        // intermediate list
        assertEquals(1, ride.intermediateStops.size)
        assertEquals("NE 10 Av & NE 180 Ter", ride.intermediateStops[0].name)
        assertEquals("4:37 PM", ride.intermediateStops[0].timeText)
        // itinerary-level agency phone + alerts (phone/alerts come from the ride leg's agency node;
        // the agency NAME keeps the trip-summary value — here itin0's — by design).
        assertEquals("Amtrak Chartered Vehicle", trip.agency)
        assertEquals("1 (305) 891-3131", trip.agencyPhone)
        assertEquals(listOf("Route 9 / 9A - Southbound Midtown Detour"), trip.alerts)
    }
}

class RouteRefTest {
    @Test
    fun classifiesRouteRefsByPrefix() {
        val i = parseRouteRef("I-80 E")
        assertEquals(ShieldType.INTERSTATE, i.type)
        assertEquals("80", i.number)
        assertEquals("E", i.direction)
        assertEquals(ShieldType.US_ROUTE, parseRouteRef("US 50").type)
        assertEquals(ShieldType.US_ROUTE, parseRouteRef("US-101 N").type)
        assertEquals(ShieldType.STATE, parseRouteRef("CA-99").type)
        assertEquals(ShieldType.STATE, parseRouteRef("ON-401").type) // Canada province
        assertEquals(ShieldType.STATE, parseRouteRef("SR 1").type)
        assertEquals(ShieldType.GENERIC, parseRouteRef("ZZ-9").type) // unknown 2-letter → plain chip
    }
}
