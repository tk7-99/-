package app.vela.core.voice

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.content.getSystemService
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/** A selectable TTS engine, e.g. Google TTS, RHVoice, eSpeak NG. */
data class VoiceEngine(val packageName: String, val label: String)

/**
 * Spoken guidance via AOSP [TextToSpeech] — no Play Services dependency, works
 * on every ROM. Stock AOSP ships Pico (robotic); GrapheneOS users typically add
 * RHVoice/eSpeak NG from F-Droid, so we enumerate installed engines and let the
 * user pick one ([availableEngines] + [enginePackage]) rather than hard-coding
 * Google's. Navigation prompts duck other audio via transient audio focus.
 */
@Singleton
class VoiceGuide @Inject constructor(
    @ApplicationContext private val context: Context,
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null

    /** Speech-rate multiplier (1.0 = normal, >1 = faster), settable live from Settings. Applied to the
     *  Android TextToSpeech engine; the neural voice reads its own `voice_speed` pref per utterance. */
    @Volatile private var speechRate = 0.97f
    // Guidance volume (issue #245). The system-TTS path can only ATTENUATE (Android's
    // KEY_PARAM_VOLUME caps at 1.0); the boost tiers act on the neural voice's own PCM.
    @Volatile private var volume = 1.0f
    fun setVolume(v: Float) {
        volume = v.coerceIn(0.2f, 3.0f)
    }
    fun setRate(rate: Float) {
        speechRate = rate.coerceIn(0.5f, 2.0f)
        tts?.setSpeechRate(speechRate)
    }
    private var ready = false
    private var currentEngine: String? = null
    private val pending = ArrayDeque<Pair<String, Boolean>>()

    // System-TTS FALLBACK for language mismatch: the neural (Piper) voice is a single-language
    // model, so when the nav text is generated in a language it can't speak (the user switched the
    // app/system language to one whose voice isn't downloaded) we route to Android TextToSpeech in
    // that language instead of mangling it through the wrong voice. `tts` holds EITHER the user's
    // chosen system engine (useNeural=false) OR this lazily-created default fallback (useNeural=true).
    private var systemReady = false
    // Set when the system-TTS engine's onInit FAILED — so speakViaSystem stops queueing into `pending`
    // forever (unbounded growth + a stale backlog that a later successful init would replay). Reset on a
    // successful init.
    private var systemInitFailed = false
    private var lastSystemLang: String? = null // avoid re-running setLanguage/selectBestVoice each utterance

    /** Invoked with a language code when guidance CAN'T speak that language (no matching neural voice
     *  AND the system TTS has no voice for it) — the UI surfaces a "download a &lt;language&gt; voice"
     *  hint so nav isn't silently mute. Set by `:app`. */
    var langUnavailable: ((String) -> Unit)? = null

    /** The Google-style rerouting EARCON: a soft two-note descending chime played when a wrong turn
     *  triggers a reroute (user 2026-07-16 - "google does this"). Synthesized in-process (no asset,
     *  no engine): two short sines with fade envelopes on the navigation-guidance stream, so it
     *  mixes/ducks exactly like spoken prompts. Muted guidance stays fully silent - the chime is
     *  part of the voice channel, not a notification. Fire-and-forget; any failure is swallowed
     *  (a missing chime must never break rerouting).
     */
    fun reroutingChime() = chime(listOf(659.25 to 140, 440.0 to 190)) // falling: something went wrong

    /** Two rising notes before "a faster route is available" (user 2026-09-23): the opposite shape
     *  of the reroute chime, so an offer never sounds like an error. Muted with the voice. */
    fun fasterRouteChime() = chime(listOf(587.33 to 120, 880.0 to 200))

    /** A list's own sound as a drive passes one of its places (PassAlerts). Muted with the voice. */
    fun placeTone(notes: List<Pair<Double, Int>>) = chime(notes)

    /** Plays [notes] (hertz to milliseconds, 30 ms apart) on the navigation-guidance stream. */
    private fun chime(notes: List<Pair<Double, Int>>) {
        if (muted) return
        Thread {
            runCatching {
                val sr = 22050
                fun tone(hz: Double, ms: Int): ShortArray {
                    val n = sr * ms / 1000
                    return ShortArray(n) { i ->
                        // ~12 ms fade in/out so the notes don't click.
                        val fade = minOf(1.0, i / (sr * 0.012), (n - 1 - i) / (sr * 0.012))
                        (kotlin.math.sin(2.0 * Math.PI * hz * i / sr) * 9500 * fade).toInt().toShort()
                    }
                }
                val gap = ShortArray(sr * 30 / 1000)
                val pcm = notes.map { (hz, ms) -> tone(hz, ms) }.reduce { a, b -> a + gap + b }
                val track = android.media.AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build(),
                    )
                    .setAudioFormat(
                        android.media.AudioFormat.Builder()
                            .setSampleRate(sr)
                            .setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO)
                            .build(),
                    )
                    .setTransferMode(android.media.AudioTrack.MODE_STATIC)
                    .setBufferSizeInBytes(pcm.size * 2)
                    .build()
                track.write(pcm, 0, pcm.size)
                track.play()
                Thread.sleep(500)
                track.release()
            }
        }.start()
    }

    /** Vela's in-process neural voice (Piper/sherpa-onnx), wired from `:app` where the native
     *  runtime lives. When the user selects [VelaPiper.ENGINE_ID], guidance goes here instead of
     *  Android TextToSpeech. Null until wired / on a build without it. */
    var neural: NeuralSynth? = null
    private var useNeural = false

    /** The language the nav text is currently GENERATED in (`NavStringsRegistry`) — the language the
     *  chosen voice must actually be able to speak. */
    private fun targetLang(): String =
        app.vela.core.i18n.NavStringsRegistry.current().locale.language.ifBlank { "en" }

    /** TTS health for the UI: null = initializing, true = a usable voice is ready,
     *  false = init failed or the chosen language has no installed voice data. Lets
     *  Settings tell the user *why* it's silent instead of failing quietly. */
    @Volatile
    var working: Boolean? = null
        private set

    /** When true, all spoken guidance is suppressed (the in-nav mute button). */
    @Volatile
    var muted = false
        set(value) {
            field = value
            if (value) stop()
        }

    private val audioManager: AudioManager? = context.getSystemService()
    private var focusRequest: AudioFocusRequest? = null
    // Audio focus is held for the whole speech BURST, refcounted per utterance. The old
    // per-utterance request/abandon pair broke on queued prompts: speak(B) overwrote A's
    // request (leaking it), then A's onDone abandoned B's — the driver's music snapped back
    // to full volume exactly while "Turn right onto Main St" was being spoken over it.
    private val focusLock = Any()
    private var activeUtterances = 0
    @Volatile private var focusHeld = false // do we currently hold audio focus? (so a new prompt during
                                            // the release-hold window doesn't needlessly re-request)
    private val focusHandler = android.os.Handler(android.os.Looper.getMainLooper())
    // Abandon focus a beat AFTER the last prompt ends (see releaseFocus) rather than instantly, so the
    // driver's music stays ducked CONTINUOUSLY across closely-spaced prompts instead of snapping back to
    // full between them — the "didn't reliably duck / not ducking enough" bug.
    private val abandonFocusRunnable = Runnable {
        synchronized(focusLock) { if (activeUtterances == 0) abandonFocus() }
    }
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        // A phone call / VOIP taking focus must SILENCE guidance — the old request had no
        // listener at all, so Vela kept announcing turns over ringing and active calls. The
        // next scheduled prompt re-fires naturally once the call releases focus.
        if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
            tts?.stop()
            neural?.stop()
            focusHandler.removeCallbacks(abandonFocusRunnable)
            synchronized(focusLock) {
                activeUtterances = 0
                abandonFocus() // inside the lock — atomic with a racing acquire's count+request
            }
        }
    }

    /** Returns true when this call REQUESTED focus (nothing was held), which is when the driver's
     *  player has not reacted yet and the first word needs a beat of lead (see [FOCUS_LEAD_MS]). */
    private fun acquireFocus(): Boolean {
        focusHandler.removeCallbacks(abandonFocusRunnable) // cancel a pending release — keep the duck continuous
        synchronized(focusLock) {
            activeUtterances += 1
            if (!focusHeld) { requestFocus(); return true } // still held from the last prompt? don't re-request
        }
        return false
    }

    /** Run [go] now when focus was already held, else after [FOCUS_LEAD_MS]: a player that pauses
     *  on a transient duck (podcast and audiobook apps do, by Android's own guidance) takes a few
     *  hundred milliseconds to stop, and the first word used to land on top of the music (user
     *  2026-09-19, "pause music a little early"). A fresh grant means nothing of ours is
     *  speaking, so nothing waits on an interrupt behind the delay. */
    private fun afterFocusLead(fresh: Boolean, go: () -> Unit) {
        if (fresh) focusHandler.postDelayed(go, FOCUS_LEAD_MS) else go()
    }

    private fun releaseFocus() {
        synchronized(focusLock) {
            if (activeUtterances > 0) activeUtterances -= 1
            if (activeUtterances == 0) {
                // Hold focus for a short tail so a compound prompt ("In 500 ft … turn right") or an
                // interrupt flushing the previous one keeps the music ducked across the gap. A new
                // acquire within FOCUS_HOLD_MS cancels this and reuses the still-held focus.
                focusHandler.removeCallbacks(abandonFocusRunnable)
                focusHandler.postDelayed(abandonFocusRunnable, FOCUS_HOLD_MS)
            }
        }
    }

    private fun releaseAllFocus() {
        focusHandler.removeCallbacks(abandonFocusRunnable)
        synchronized(focusLock) {
            activeUtterances = 0
            abandonFocus()
        }
    }

    /** Initialize, or **re-initialize** if [enginePackage] differs from the engine
     *  currently loaded — so picking a different engine in Settings actually takes
     *  effect (the old idempotent guard ignored later picks). */
    fun init(enginePackage: String? = null) {
        // One of Vela's own in-process neural voices (vela.piper) — no Android TextToSpeech
        // involved. The right synth is wired into [neural] by MapViewModel first. Do NOT shut the
        // system `tts` down here — it stays as the fallback for languages the neural voice can't
        // speak (see speakViaSystem); an unused instance is cheap.
        if (enginePackage != null && enginePackage.startsWith("vela.")) {
            if (useNeural && enginePackage == currentEngine) return
            currentEngine = enginePackage
            useNeural = true
            ready = true // the neural synth loads + queues internally
            working = neural != null
            neural?.warmUp()
            drainPendingLatest()
            return
        }
        useNeural = false
        neural?.stop()
        if (tts != null && enginePackage == currentEngine) return
        if (tts != null) shutdown()
        currentEngine = enginePackage
        working = null
        ready = false
        systemReady = false
        lastSystemLang = null
        tts = if (enginePackage != null) {
            TextToSpeech(context, this, enginePackage)
        } else {
            TextToSpeech(context, this)
        }
        attachTtsListener()
    }

    private fun attachTtsListener() {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) = releaseFocus()
            // QUEUE_FLUSH fires onStop (not onDone) for the flushed utterance — without this
            // override every interrupt stranded a refcount and focus never released.
            override fun onStop(utteranceId: String?, interrupted: Boolean) = releaseFocus()
            @Deprecated("deprecated") override fun onError(utteranceId: String?) {
                working = false // the engine accepted text but couldn't synthesize it
                releaseFocus()
            }
        })
    }

    /** Speak a sample so the user can confirm the engine actually makes sound (the
     *  only true test on their hardware — we can't hear it for them). */
    fun test() = speak(app.vela.core.i18n.NavStringsRegistry.current().voiceTest(), interrupt = true, ignoreMute = true)

    override fun onInit(status: Int) {
        val t = tts
        if (status != TextToSpeech.SUCCESS || t == null) {
            systemReady = false
            systemInitFailed = true
            if (!useNeural) working = false // the PRIMARY engine failed to start
            pending.clear() // nothing can speak the backlog — drop it instead of replaying it on a later init
            if (useNeural) langUnavailable?.invoke(targetLang()) // fallback engine dead → "download a <lang> voice"
            return
        }
        // A measured pace + neutral pitch reads more like a real nav voice than the engine default.
        // The LANGUAGE is set per-utterance now (speakViaSystem), keyed on the nav-text language —
        // so a mid-drive app/system-language change is honored and the engine never reads a
        // language it has no voice for.
        t.setSpeechRate(speechRate)
        t.setPitch(1.0f)
        systemReady = true
        systemInitFailed = false
        lastSystemLang = null // force setLanguage on the first utterance
        if (!useNeural) { ready = true; working = true } // this system engine is the PRIMARY voice
        drainPendingLatest()
    }

    /** Speak only the MOST RECENT queued line when a voice (re-)attaches, never the whole backlog.
     *  Prompts pile into [pending] while nothing can speak them (a drive with no voice installed,
     *  then the user installs one mid-way or afterward); replaying the entire pile dumps a burst of
     *  stale, out-of-order instructions all at once (user 2026-07-20: "it automatically started
     *  speaking... random letters"). Only the latest is still relevant, and the live nav loop
     *  re-announces the current maneuver anyway. */
    private fun drainPendingLatest() {
        val last = pending.lastOrNull()
        pending.clear()
        last?.let { (text, interrupt) -> speakNow(text, interrupt) }
    }

    /** Pick the highest-quality voice for [lang] that works offline — engines
     *  often default to a low-quality or download-required voice; this lifts
     *  guidance to the best installed one so it sounds natural in the car. */
    private fun selectBestVoice(t: TextToSpeech, lang: Locale) {
        runCatching {
            val best = t.voices.orEmpty()
                .filter {
                    it.locale.language == lang.language &&
                        !it.isNetworkConnectionRequired &&
                        it.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) != true
                }
                .maxByOrNull { it.quality }
            if (best != null) t.voice = best
        }
    }

    /** Every TTS engine the user can pick: Vela's neural voice first (when its model is downloaded),
     *  then every system TTS engine installed on the phone. Enumerated via [android.content.pm.PackageManager]
     *  (the TTS_SERVICE intent) so the list is complete even when no Android [TextToSpeech] instance
     *  is active — e.g. while the neural voice is the current engine and `tts` is null. */
    // Cache the SLOW part — enumerating system TTS engines is a PackageManager binder IPC plus a
    // per-engine loadLabel (resource load), which took >5 s on a slow flip phone and ANR'd the UI
    // when called in composition. System engines don't install/uninstall mid-session, so cache the
    // list for the process; the Vela neural entry is recomputed each call so it appears the instant
    // its model finishes downloading. Callers should still make the FIRST call off the main thread.
    @Volatile private var installedEnginesCache: List<VoiceEngine>? = null

    fun availableEngines(): List<VoiceEngine> {
        val installed = installedEnginesCache ?: run {
            val pm = context.packageManager
            val list = runCatching {
                pm.queryIntentServices(Intent("android.intent.action.TTS_SERVICE"), 0)
                    .mapNotNull { it.serviceInfo }
                    .map { VoiceEngine(it.packageName, it.loadLabel(pm).toString()) }
                    .distinctBy { it.packageName }
            }.getOrElse { tts?.engines.orEmpty().map { VoiceEngine(it.name, it.label) } }
            installedEnginesCache = list
            list
        }
        val vela = if (VelaPiper.isReady(context)) listOf(VoiceEngine(VelaPiper.ENGINE_ID, VelaPiper.LABEL)) else emptyList()
        return vela + installed
    }

    /** Speak [text]; [interrupt] flushes the queue (use for the imminent turn). [ignoreMute] is for
     *  EXPLICIT speak-this-now actions (the Test button, the voice playground): a user who taps
     *  "speak" wants sound even while spoken directions are toggled off - the persisted mute
     *  silently eating those taps read as "sometimes it plays, sometimes not" (user 2026-07-10). */
    /** Fired with every line guidance ACTUALLY speaks (post-mute gate) - the trip recorder taps
     *  this so a shared drive shows what was said, verbatim, at what time. Set by `:app`. */
    var onSpoken: ((String) -> Unit)? = null

    /** Fired beside [onSpoken] on every line guidance actually speaks. The nav service taps this
     *  to pop a visible heads-up of the turn while the app is backgrounded - a separate slot so
     *  it can't clobber the trip recorder's hook (each is set by a different `:app` owner). */
    var onPromptAlert: (() -> Unit)? = null

    /** Real romanized road names (local name -> Latin, from the basemap's name:latin), set by `:app`
     *  as nav tiles load. Used to speak "Rehov Herzl" instead of the ICU skeleton "rhwb hrzl" for a
     *  foreign street; empty by default so nothing changes without it (issue #184). */
    @Volatile var roadNameLatin: Map<String, String> = emptyMap()

    // Bumped by stop()/a new opener so a deferred nav-start opener (see speakOpener) that is still
    // waiting for its road name to romanize gets canceled instead of speaking into a dead session.
    @Volatile private var openerToken = 0
    private val OPENER_MAX_WAIT_MS = 2500L // cap the nav-start opener's wait for its romanized road name

    fun speak(text: String, interrupt: Boolean = false, ignoreMute: Boolean = false) {
        if (muted && !ignoreMute) return
        runCatching { onSpoken?.invoke(text) }
        runCatching { onPromptAlert?.invoke() }
        if (!ready) {
            pending.addLast(text to interrupt)
            return
        }
        speakNow(text, interrupt)
    }

    /** Get [text] ready to speak ahead of time (the drive's opener, prepared while the route preview
     *  is up), so the line needs no synthesis when it is spoken. Only the neural voice can keep
     *  audio; the same voice choice and text changes as [speakNow], so the prepared line matches. */
    fun prepare(text: String, onDone: () -> Unit = {}) {
        val t = targetLang()
        val n = neural
        // Before the first drive nothing is initialized yet (init runs at Start) and [neural] is
        // the chosen voice; once a system engine is the active one, there is nothing to prepare.
        if (muted || n == null || (currentEngine != null && !useNeural) ||
            !(n.voiceLanguage.let { it == null || it == t } || n.voiceFor(t))
        ) { onDone(); return }
        n.prepare(forSpeech(SpokenScript.forVoice(text, n.voiceLanguage ?: t, roadNameLatin)), onDone)
    }

    /** Speak the nav-START opener ("Starting navigation. Head ... on <road>"), but hold it briefly if
     *  its road name is still in a foreign script we have no real romanization for yet (issue #184). A
     *  drive begins before the nav-zoom tiles load, so speaking immediately reads the ICU skeleton
     *  ("rhwb hrzl"); waiting a beat lets [roadNameLatin] fill so the opener says the real name ("Rehov Herzl").
     *  Retries every 200 ms up to [OPENER_MAX_WAIT_MS], then speaks whatever we have (never silent).
     *  An all-Latin opener, or one whose road is already covered, speaks instantly. */
    fun speakOpener(text: String) {
        val token = ++openerToken
        val deadline = SystemClock.elapsedRealtime() + OPENER_MAX_WAIT_MS
        fun attempt() {
            if (token != openerToken) return // a newer start / a stop superseded this opener
            val covered = roadNameLatin.keys.any { it.isNotEmpty() && text.contains(it) }
            val ready = covered || !hasForeignRun(text) || SystemClock.elapsedRealtime() >= deadline
            // Urgent: nothing is playing at a start, and it must not wait for the voice to load at
            // background priority or behind prepare-ahead work (9 s on a cold start, 4a 2026-10-03).
            if (ready) speak(text, interrupt = true) else focusHandler.postDelayed(::attempt, 200)
        }
        attempt()
    }

    /** True if [text] has a letter in a script other than Latin (so an English opener never waits). */
    private fun hasForeignRun(text: String): Boolean = text.any {
        Character.isLetter(it) && Character.UnicodeScript.of(it.code) != Character.UnicodeScript.LATIN
    }

    private fun speakNow(text: String, interrupt: Boolean) {
        val t = targetLang()
        val n = neural
        // Use the neural voice ONLY when it can actually speak the target language. A single-
        // language Piper model reading another language's text is gibberish (the "English voice
        // read Russian" bug) — voiceLanguage==null means unknown → trust it (old behavior).
        // ...or when another INSTALLED voice speaks it (the phone switched to Russian mid-drive
        // with Irina installed): the synth swaps the loaded voice, the selection stays.
        if (useNeural && n != null && (n.voiceLanguage.let { it == null || it == t } || n.voiceFor(t))) {
            // The neural synth fires onDone exactly ONCE per speak() (including aborted/
            // interrupted utterances — PiperSynth's finally), so the refcount balances without
            // any interrupt special-casing. Do NOT reset the count here: the interrupted
            // utterance's own onDone is still in flight and a reset would double-count it,
            // abandoning focus while the interrupting prompt speaks.
            val fresh = acquireFocus()
            // Romanize any foreign-script name for this (Latin) neural voice so it isn't dropped
            // (issue #184); the on-screen banner keeps the real local-script name.
            val spoken = forSpeech(SpokenScript.forVoice(text, n.voiceLanguage ?: t, roadNameLatin))
            afterFocusLead(fresh) { n.speak(spoken, interrupt) { releaseFocus() } }
            return
        }
        speakViaSystem(text, interrupt, t)
    }

    /** Speak through Android TextToSpeech in language [t] — the user's chosen system engine, or a
     *  lazily-created default engine when the neural voice can't cover [t]. If the system TTS has no
     *  voice for [t] either, stay SILENT (never read [t]'s text with a non-[t] voice) and surface the
     *  download hint. */
    private fun speakViaSystem(text: String, interrupt: Boolean, t: String) {
        val engine = tts ?: run { ensureSystemTts(); null }
        if (engine == null || !systemReady) {
            if (systemInitFailed) langUnavailable?.invoke(t) // init already failed — don't queue into a void forever
            else pending.addLast(text to interrupt) // drained by onInit once the fallback engine is ready
            return
        }
        if (t != lastSystemLang) {
            val avail = runCatching { engine.setLanguage(Locale(t)) }.getOrDefault(TextToSpeech.LANG_NOT_SUPPORTED)
            if (avail < TextToSpeech.LANG_AVAILABLE) {
                working = false
                langUnavailable?.invoke(t) // "download a <language> voice" — don't mangle it through the wrong one
                return
            }
            selectBestVoice(engine, Locale(t))
            engine.setSpeechRate(speechRate)
            engine.setPitch(1.0f)
            lastSystemLang = t
            working = true
        }
        // A FLUSH stops the current utterance + drops the queue; their onStop callbacks
        // decrement, so just acquire for the new utterance.
        val fresh = acquireFocus()
        afterFocusLead(fresh) { speakViaSystemNow(engine, text, interrupt, t) }
    }

    private fun speakViaSystemNow(engine: TextToSpeech, text: String, interrupt: Boolean, t: String) {
        val mode = if (interrupt) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        // Same foreign-name romanizing as the neural path (issue #184): the system voice for [t]
        // is Latin-script for the Latin languages, so a foreign road name would otherwise be lost.
        val params = android.os.Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume.coerceAtMost(1.0f))
        }
        val result = engine.speak(forSpeech(SpokenScript.forVoice(text, t, roadNameLatin)), mode, params, "vela-${text.hashCode()}")
        if (result == TextToSpeech.ERROR) {
            // The utterance was never enqueued, so NONE of the onDone/onStop/onError callbacks that
            // release focus will ever fire for it — roll back the acquire here or music stays ducked
            // forever (audit 2026-07-06). Also surface the dead engine like the onError path does.
            releaseFocus()
            working = false
        }
    }

    /** Lazily create the DEFAULT system TTS engine as the neural-mismatch fallback, without touching
     *  the neural selection (`useNeural`/`currentEngine` stay put). Its `onInit` sets [systemReady]. */
    private fun ensureSystemTts() {
        if (tts != null) return
        systemReady = false
        lastSystemLang = null
        tts = TextToSpeech(context, this)
        attachTtsListener()
    }

    /** Expand road abbreviations so the engine SAYS them instead of spelling them: "St" →
     *  "Street", "Pkwy" → "Parkway", "N" → "North", "I-80" → "Interstate 80". Google's markup
     *  (and so the on-screen banner) keeps the compact forms; this is for the spoken text only.
     *  Whole-word, so it never mangles a name that merely contains the letters. */
    private fun forSpeech(text: String): String =
        app.vela.core.i18n.NavStringsRegistry.current().expandForSpeech(text)

    fun stop() {
        openerToken++ // cancel any deferred nav-start opener still waiting for its road name
        tts?.stop()
        neural?.stop()
        // Drop any queued-but-unspoken prompts: once guidance stops (nav end / mute), a backlog is
        // stale and must not survive to be flushed later when a voice attaches (issue: stale burst).
        pending.clear()
        releaseAllFocus()
    }

    fun shutdown() {
        tts?.shutdown()
        tts = null
        ready = false
        systemReady = false
        lastSystemLang = null
        neural?.stop()
        releaseAllFocus()
    }

    private fun requestFocus() {
        val am = audioManager ?: return
        // ONE request object reused for the burst (see acquire/releaseFocus) — building a fresh request
        // per utterance is what leaked the previous one. GAIN_TRANSIENT_MAY_DUCK, NOT plain GAIN_TRANSIENT:
        // MAY_DUCK is OS-managed — the system ducks the driver's music AND auto-restores it when we abandon,
        // bulletproof. Plain TRANSIENT PAUSES the media, and many players don't reliably auto-resume when
        // focus is handed back ("Vela paused the music and didn't restart it"). The real cause of the
        // earlier "not ducking enough" was the FLAPPING (focus dropped between every prompt → music popped
        // back to full mid-turn), which the release-hold above fixes — so the duck is now continuous, which
        // is what actually reads as "ducked", without the pause-and-never-resume risk. (Duck DEPTH is set by
        // the OS/player and isn't tunable via the focus API; pause is the only thing deeper, and its resume
        // is unreliable — so continuous MAY_DUCK is the safe answer.)
        val req = focusRequest ?: run {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener(focusListener, focusHandler)
                .build()
                .also { focusRequest = it }
        }
        // Track whether we actually got focus — a FAILED request means the media app never ducked
        // (Vela used to speak over full-volume audio and never know); GRANTED or DELAYED both hold.
        focusHeld = am.requestAudioFocus(req) != AudioManager.AUDIOFOCUS_REQUEST_FAILED
    }

    private fun abandonFocus() {
        focusHeld = false
        val am = audioManager ?: return
        focusRequest?.let { am.abandonAudioFocusRequest(it) }
        focusRequest = null
    }

    private companion object {
        // Keep audio focus this long after the last prompt so back-to-back prompts don't flap the
        // driver's music on/off between them. Short enough that music resumes promptly after a cluster.
        const val FOCUS_HOLD_MS = 1500L
        // Lead between a FRESH focus grant and the first sample, so a pausing player has stopped.
        const val FOCUS_LEAD_MS = 350L
    }
}
// (Road-abbreviation → spoken-form expansion moved to EnNavStrings.expandForSpeech in core/i18n, so it's
//  English-scoped and opt-in — other languages leave road names untouched.)
