package app.vela.offline

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Open BUILDING-FOOTPRINT overlays (Microsoft US Building Footprints, ODbL) as **PMTiles** — the
 * gap-fill sibling of [ObfStore]. Each region is ONE `.pmtiles` archive (no unzip, unlike the
 * routing graph's folder) downloaded into `filesDir/overlays/<id>.pmtiles`, with an `index.json`
 * (`[{id, bbox:[S,W,N,E]}]`) the map view reads to add a `pmtiles://` source + a fill layer BENEATH the
 * OSM building layer, so footprints only fill where OSM is thin (a suburb the Microsoft→OSM import missed).
 *
 * Reuses [RoutingRegion] as the manifest row (same `{id,name,url,sizeMb,bbox}` shape) — the overlay manifest
 * (`OVERLAY_MANIFEST_URL`) is built by the same CI pattern as the routing one.
 */
@Singleton
class OverlayTileStore @Inject constructor(
    @ApplicationContext private val context: Context,
    private val http: OkHttpClient,
) {
    private val overlaysRoot: File get() = File(app.vela.offline.StorageLocation.root(context), "overlays")
    private val indexFile: File get() = File(overlaysRoot, "index.json")

    // Serialize downloads so two callers requesting the SAME region can't interleave writes into the one
    // `<id>.pmtiles.tmp` (the 7-byte magic check could then pass on a corrupt archive) and can't race the
    // index read-modify-write. Voice/routing serialize at the ViewModel; do it in the store so every caller
    // is covered (audit 2026-07-06). indexLock also guards delete()'s index mutation vs a download.
    private val downloadMutex = kotlinx.coroutines.sync.Mutex()
    private val indexLock = Any()

    // A ~200 MB PMTiles download blows past the shared client's 12s callTimeout (that bound exists to
    // cap a hung *scrape*, not a large file) — the call aborts mid-stream, runCatching swallows it, and
    // the overlay silently never installs. Derive an unbounded-call client for the body download, same
    // fix KokoroInstaller uses for voice models. Manifest fetches stay on the short-timeout shared client.
    private val downloadHttp: OkHttpClient = http.newBuilder()
        .callTimeout(0, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    /** id → the `.pmtiles` file, for the regions actually present on disk. */
    fun installed(): Map<String, File> =
        readIndex().keys.mapNotNull { id -> fileFor(id).takeIf { it.exists() }?.let { id to it } }.toMap()

    fun installedIds(): Set<String> = installed().keys

    private fun fileFor(id: String) = File(overlaysRoot, "$id.pmtiles")

    /** Installed regions + bbox (`[S,W,N,E]`), so the map view can add only the overlays that exist. */
    fun installedRegions(): List<Pair<String, DoubleArray>> =
        readIndex().filterKeys { fileFor(it).exists() }.map { it.key to it.value }

    /** Fetch the catalog of available overlays from [manifestUrl] (same shape as the routing manifest). */
    suspend fun manifest(manifestUrl: String): List<RoutingRegion> = withContext(Dispatchers.IO) {
        runCatching {
            val json = http.newCall(Request.Builder().url(manifestUrl).build()).execute()
                .use { r -> if (!r.isSuccessful) error("HTTP ${r.code}"); r.body!!.string() }
            val arr = JSONObject(json).getJSONArray("regions")
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val b = o.getJSONArray("bbox") // [S, W, N, E]
                RoutingRegion(
                    o.getString("id"), o.getString("name"), o.getString("url"), o.optInt("sizeMb"),
                    b.getDouble(0), b.getDouble(1), b.getDouble(2), b.getDouble(3),
                )
            }
        }.getOrDefault(emptyList())
    }

    /** Download [region]'s `.pmtiles` into `overlays/<id>.pmtiles` (atomic via a .tmp) + register it. 0..100. */
    suspend fun download(region: RoutingRegion, onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        downloadMutex.withLock {
        // A duplicate request queued behind the first is a no-op, not a re-download.
        if (region.id in readIndex() && fileFor(region.id).exists()) { onProgress(100); return@withLock true }
        overlaysRoot.mkdirs()
        val file = fileFor(region.id)
        val tmp = File(overlaysRoot, "${region.id}.pmtiles.tmp")
        runCatching {
            downloadHttp.newCall(Request.Builder().url(region.url).build()).execute().use { resp ->
                if (!resp.isSuccessful) error("HTTP ${resp.code}")
                val total = resp.body!!.contentLength()
                var lastPct = -1
                val counting = CountingInputStream(resp.body!!.byteStream()) { read ->
                    if (total > 0) (100 * read / total).toInt().let { p -> if (p != lastPct) { lastPct = p; onProgress(p) } }
                }
                tmp.outputStream().use { counting.copyTo(it) }
            }
            // PMTiles v3 archives start with the 7-byte magic "PMTiles"; guard against an HTML error page
            // slipping through as a "download" (which would blank the map source, not just fail quietly).
            check(tmp.length() > 127 && tmp.inputStream().use { s -> ByteArray(7).let { s.read(it); String(it) } } == "PMTiles")
                { "downloaded overlay isn't a PMTiles archive" }
            file.delete()
            check(tmp.renameTo(file)) { "could not install overlay (rename failed)" }
            synchronized(indexLock) { writeIndex(readIndex() + (region.id to doubleArrayOf(region.s, region.w, region.n, region.e))) }
            onProgress(100)
            true
        }.getOrElse { tmp.delete(); false }
        }
    }

    fun delete(id: String) {
        fileFor(id).delete()
        synchronized(indexLock) { writeIndex(readIndex() - id) }
    }

    private fun readIndex(): Map<String, DoubleArray> = runCatching {
        if (!indexFile.exists()) return emptyMap()
        val arr = JSONArray(indexFile.readText())
        (0 until arr.length()).associate { i ->
            val o = arr.getJSONObject(i); val b = o.getJSONArray("bbox")
            o.getString("id") to doubleArrayOf(b.getDouble(0), b.getDouble(1), b.getDouble(2), b.getDouble(3))
        }
    }.getOrDefault(emptyMap())

    private fun writeIndex(map: Map<String, DoubleArray>) {
        overlaysRoot.mkdirs()
        val arr = JSONArray()
        map.forEach { (id, b) ->
            arr.put(JSONObject().put("id", id).put("bbox", JSONArray().put(b[0]).put(b[1]).put(b[2]).put(b[3])))
        }
        app.vela.core.util.AtomicFiles.writeText(indexFile, arr.toString())
    }
}
