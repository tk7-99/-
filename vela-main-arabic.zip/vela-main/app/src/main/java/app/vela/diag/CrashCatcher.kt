package app.vela.diag

import android.content.Context
import android.content.Intent
import android.os.Build
import app.vela.BuildConfig
import app.vela.core.diag.DiagEvent
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * Catches an otherwise-fatal uncaught exception and **persists** a crash report —
 * stack trace, app/device versions, and whatever diagnostic breadcrumbs were in
 * memory — to a file under `filesDir/diag/crash/`, then chains to the system's
 * default handler so the normal crash flow is unchanged.
 *
 * Why this exists: when nav crashed on a phone that wasn't tethered, there was no
 * way to get the stack trace. This keeps it on disk so the user can **export the
 * crash report on the next launch** (Settings → Diagnostics) and hand it to a dev.
 *
 * The stack trace + device info are benign (no personal data), so a report is
 * written even if the opt-in diagnostics log is off — the breadcrumb section is
 * simply empty in that case (breadcrumbs are only recorded when the user opted in).
 * The report never leaves the phone unless the user exports + shares it.
 */
object CrashCatcher {

    fun install(context: Context, breadcrumbs: () -> List<DiagEvent>) {
        val app = context.applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, ex ->
            runCatching { writeReport(app, ex, breadcrumbs()) }
            prev?.uncaughtException(thread, ex)
        }
    }

    private fun dir(context: Context) = File(context.filesDir, "diag/crash").apply { mkdirs() }

    private fun writeReport(context: Context, ex: Throwable, crumbs: List<DiagEvent>) {
        val sw = StringWriter()
        ex.printStackTrace(PrintWriter(sw))
        val text = buildString {
            append("Vela crash report\n")
            append("when: ").append(System.currentTimeMillis()).append('\n')
            append("version: ").append(BuildConfig.VERSION_NAME).append(" (").append(BuildConfig.VERSION_CODE).append(")\n")
            append("android: API ").append(Build.VERSION.SDK_INT)
                .append(" — ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append("\n\n")
            append("=== settings ===\n").append(SettingsDump.line(context)).append("\n\n")
            append("=== stack trace ===\n").append(sw.toString()).append('\n')
            append("=== breadcrumbs (").append(crumbs.size).append(") ===\n")
            crumbs.forEach { e ->
                append(e.epochMs).append(" [").append(e.kind).append("] ").append(e.summary)
                e.detail?.let { append(" :: ").append(it) }
                append('\n')
            }
        }
        File(dir(context), "crash-${System.currentTimeMillis()}.txt").writeText(text)
        prune(context)
    }

    /** Keep only the few most recent reports so this can't grow unbounded. */
    private fun prune(context: Context, keep: Int = 5) {
        val files = pending(context)
        if (files.size > keep) files.dropLast(keep).forEach { runCatching { it.delete() } }
    }

    /** Crash reports on disk, oldest first. */
    fun pending(context: Context): List<File> =
        dir(context).listFiles { f -> f.isFile && f.name.startsWith("crash-") }?.sortedBy { it.name } ?: emptyList()

    fun clear(context: Context) {
        pending(context).forEach { runCatching { it.delete() } }
    }

    /** Share the most recent crash report via the system sheet, or null if none. */
    fun shareIntent(context: Context): Intent? {
        val newest = pending(context).lastOrNull() ?: return null
        return shareFileIntent(
            context, newest,
            mime = "text/plain",
            subject = if (app.vela.ui.AppLocale.language.value == "ar") "تقرير تعطل ڤيلا" else "Vela crash report",
            text = if (app.vela.ui.AppLocale.language.value == "ar") "مرفق تقرير تعطل ڤيلا، ويحتوي على تفاصيل الخطأ ومعلومات التشخيص." else "Attached: a Vela crash report (stack trace + diagnostics).",
            title = if (app.vela.ui.AppLocale.language.value == "ar") "مشاركة تقرير التعطّل" else "Share crash report",
        )
    }
}
